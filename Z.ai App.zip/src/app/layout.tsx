import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AI App Builder - Open Source AI-Powered Code Generation",
  description: "Build, debug, and optimize code with AI. A powerful app builder integrating open-source AI models like Qwen, DeepSeek, LLaMA, and more for code generation, debugging, and prototyping.",
  keywords: ["AI App Builder", "Code Generation", "AI Debugging", "Open Source AI", "Qwen", "DeepSeek", "LLaMA", "Next.js", "TypeScript"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "AI App Builder - Powered by Open Source AI",
    description: "Generate, debug, and optimize code with cutting-edge open-source AI models",
    url: "https://chat.z.ai",
    siteName: "AI App Builder",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AI App Builder",
    description: "Generate, debug, and optimize code with AI",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <SonnerToaster />
      </body>
    </html>
  );
}
