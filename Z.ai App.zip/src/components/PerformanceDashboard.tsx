'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import {
  Activity,
  Zap,
  Clock,
  Cpu,
  HardDrive,
  Network,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  RefreshCw
} from 'lucide-react'

interface MetricData {
  name: string
  value: string | number
  unit?: string
  trend?: 'up' | 'down' | 'stable'
  trendValue?: number
  status?: 'good' | 'warning' | 'error'
  history?: Array<number>
}

interface PerformanceMetrics {
  buildTime: MetricData
  bundleSize: MetricData
  firstLoad: MetricData
  apiResponse: MetricData
  editorLoad: MetricData
  terminalConnect: MetricData
  memoryUsage: MetricData
  cpuUsage: MetricData
  networkLatency: MetricData
}

export default function PerformanceDashboard() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    buildTime: {
      name: 'Build Time',
      value: 12.0,
      unit: 's',
      trend: 'down',
      trendValue: -1.5,
      status: 'good',
      history: [15, 14.5, 13, 12.5, 12]
    },
    bundleSize: {
      name: 'Bundle Size',
      value: 98.3,
      unit: 'kB',
      trend: 'down',
      trendValue: -5.2,
      status: 'good',
      history: [110, 105, 100, 98, 98.3]
    },
    firstLoad: {
      name: 'First Load JS',
      value: 223,
      unit: 'kB',
      trend: 'down',
      trendValue: -12,
      status: 'good',
      history: [250, 240, 235, 228, 223]
    },
    apiResponse: {
      name: 'API Response',
      value: 450,
      unit: 'ms',
      trend: 'stable',
      status: 'good',
      history: [440, 455, 448, 452, 450]
    },
    editorLoad: {
      name: 'Editor Load',
      value: 800,
      unit: 'ms',
      trend: 'down',
      trendValue: -100,
      status: 'good',
      history: [1000, 950, 900, 850, 800]
    },
    terminalConnect: {
      name: 'Terminal Connect',
      value: 150,
      unit: 'ms',
      trend: 'stable',
      status: 'good',
      history: [145, 155, 148, 152, 150]
    },
    memoryUsage: {
      name: 'Memory Usage',
      value: 45,
      unit: '%',
      trend: 'up',
      trendValue: 5,
      status: 'warning',
      history: [40, 42, 43, 44, 45]
    },
    cpuUsage: {
      name: 'CPU Usage',
      value: 35,
      unit: '%',
      trend: 'stable',
      status: 'good',
      history: [32, 38, 35, 36, 35]
    },
    networkLatency: {
      name: 'Network Latency',
      value: 45,
      unit: 'ms',
      trend: 'up',
      trendValue: 5,
      status: 'good',
      history: [38, 40, 42, 43, 45]
    }
  })

  const [isRefreshing, setIsRefreshing] = useState(false)

  const refreshMetrics = useCallback(() => {
    setIsRefreshing(true)

    // Simulate fetching metrics from API
    setTimeout(() => {
      // In production, this would fetch real metrics
      console.log('Refreshing metrics...')

      // Simulate slight variations
      setMetrics(prev => ({
        ...prev,
        apiResponse: {
          ...prev.apiResponse,
          value: Math.round(400 + Math.random() * 200)
        },
        memoryUsage: {
          ...prev.memoryUsage,
          value: Math.round(35 + Math.random() * 20)
        },
        cpuUsage: {
          ...prev.cpuUsage,
          value: Math.round(20 + Math.random() * 30)
        }
      }))

      setIsRefreshing(false)
    }, 1000)
  }, [])

  useEffect(() => {
    // Auto-refresh metrics every 10 seconds
    const interval = setInterval(() => {
      refreshMetrics()
    }, 10000)

    return () => clearInterval(interval)
  }, [refreshMetrics])

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'good':
        return 'text-green-600 dark:text-green-400'
      case 'warning':
        return 'text-yellow-600 dark:text-yellow-400'
      case 'error':
        return 'text-red-600 dark:text-red-400'
      default:
        return 'text-gray-600 dark:text-gray-400'
    }
  }

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case 'good':
        return <Activity className="w-3 h-3" />
      case 'warning':
        return <AlertCircle className="w-3 h-3" />
      case 'error':
        return <AlertCircle className="w-3 h-3" />
      default:
        return <Activity className="w-3 h-3" />
    }
  }

  const getTrendIcon = (trend?: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="w-3 h-3 text-green-600" />
      case 'down':
        return <TrendingDown className="w-3 h-3 text-green-600" />
      default:
        return <Activity className="w-3 h-3" />
    }
  }

  const getMetricIcon = (name: string) => {
    const icons: Record<string, any> = {
      'Build Time': <Clock className="w-4 h-4" />,
      'Bundle Size': <HardDrive className="w-4 h-4" />,
      'First Load JS': <Zap className="w-4 h-4" />,
      'API Response': <Network className="w-4 h-4" />,
      'Editor Load': <Cpu className="w-4 h-4" />,
      'Terminal Connect': <Network className="w-4 h-4" />,
      'Memory Usage': <HardDrive className="w-4 h-4" />,
      'CPU Usage': <Cpu className="w-4 h-4" />,
      'Network Latency': <Network className="w-4 h-4" />
    }
    return icons[name] || <Activity className="w-4 h-4" />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold">Performance Dashboard</h1>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={refreshMetrics}
          disabled={isRefreshing}
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Refreshing...' : 'Refresh'}
        </Button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {(Object.entries(metrics) as [string, MetricData][]).slice(0, 4).map(([key, metric]) => (
          <Card key={key}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getMetricIcon(metric.name)}
                  <CardTitle className="text-sm">{metric.name}</CardTitle>
                </div>
                <div className="flex items-center gap-1">
                  {getTrendIcon(metric.trend)}
                  <Badge variant={metric.status === 'good' ? 'default' : metric.status === 'warning' ? 'secondary' : 'destructive'}>
                    {metric.status}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-1">
                {typeof metric.value === 'number' ? metric.value.toFixed(1) : metric.value}
                {metric.unit && <span className="text-lg text-muted-foreground ml-1">{metric.unit}</span>}
              </div>
              {metric.trendValue && (
                <div className={`text-sm ${getStatusColor(metric.status)}`}>
                  {metric.trendValue > 0 ? '+' : ''}{metric.trendValue}% vs last
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Metrics</CardTitle>
          <CardDescription>Real-time performance monitoring</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="space-y-4">
              {(Object.entries(metrics) as [string, MetricData][]).map(([key, metric]) => (
                <div key={key} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getMetricIcon(metric.name)}
                      <span className="text-sm font-medium">{metric.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">
                        {typeof metric.value === 'number' ? metric.value.toFixed(1) : metric.value}
                        {metric.unit && <span className="text-muted-foreground ml-1">{metric.unit}</span>}
                      </span>
                      {getTrendIcon(metric.trend)}
                    </div>
                  </div>

                  {/* History Chart */}
                  {metric.history && metric.history.length > 1 && (
                    <div className="h-12 flex items-end gap-0.5 bg-muted rounded p-2">
                      {metric.history.map((value, index) => {
                        const max = Math.max(...metric.history)
                        const min = Math.min(...metric.history)
                        const range = max - min || 1
                        const height = ((value - min) / range) * 100

                        return (
                          <div
                            key={index}
                            className="flex-1 rounded-sm"
                            style={{
                              height: `${Math.max(10, height)}%`,
                              backgroundColor: index === metric.history.length - 1
                                ? 'hsl(217, 91%, 60%)'
                                : 'hsl(217, 91%, 80%)'
                            }}
                          />
                        )
                      })}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* System Health */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">System Health</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Status</span>
              <Badge variant="default">Healthy</Badge>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-sm">Uptime</span>
              <span className="text-sm font-semibold">99.9%</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-sm">Requests/min</span>
              <span className="text-sm font-semibold">247</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Service Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Next.js</span>
              <Badge variant="outline" className="text-green-600">Running</Badge>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Terminal</span>
              <Badge variant="outline" className="text-green-600">Connected</Badge>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Web Builder</span>
              <Badge variant="outline" className="text-green-600">Ready</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start">
              <Activity className="w-4 h-4 mr-2" />
              View Detailed Logs
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <Zap className="w-4 h-4 mr-2" />
              Run Diagnostics
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start">
              <HardDrive className="w-4 h-4 mr-2" />
              Clear Cache
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
