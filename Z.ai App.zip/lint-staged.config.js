module.exports = {
  '*.{ts,tsx}': [
    'bunx eslint --fix',
    'bunx prettier --write',
    'bunx tsc --noEmit --pretty'
  ],
  '*.{js,jsx}': [
    'bunx eslint --fix',
    'bunx prettier --write'
  ],
  '*.{json,md,yml,yaml}': [
    'bunx prettier --write'
  ],
  '*.{css,scss}': [
    'bunx stylelint --fix',
    'bunx prettier --write'
  ],
  'package.json': [
    'bunx prettier --write',
    'bunx npm-check'
  ]
}
