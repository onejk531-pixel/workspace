import { useCallback } from 'react'

interface BatchingOptions {
  delay?: number // Delay before batching (ms)
  maxSize?: number // Max items in a batch
}

export function useRequestBatching<T = any>(
  options: BatchingOptions = {}
) {
  const {
    delay = 100,
    maxSize = 10
  } = options

  const pendingRequests = useRef(new Map<string, Promise<T>>())
  const batchingTimer = useRef<NodeJS.Timeout>()
  const pendingItems = useRef<Array<{ key: string; requestFn: () => Promise<T> }>>([])

  const batchExecute = useCallback(async () => {
    if (pendingItems.current.length === 0) {
      return
    }

    const itemsToProcess = pendingItems.current.splice(0, maxSize)
    console.log(`[Batch] Processing ${itemsToProcess.length} requests`)

    // Process batch in parallel with size limit
    const BATCH_SIZE = 5
    for (let i = 0; i < itemsToProcess.length; i += BATCH_SIZE) {
      const batch = itemsToProcess.slice(i, i + BATCH_SIZE)

      const promises = batch.map(({ key, requestFn }) => {
        const promise = requestFn()
          .finally(() => {
            pendingRequests.current.delete(key)
          })

        pendingRequests.current.set(key, promise)
        return promise
      })

      // Wait for this batch to complete
      await Promise.all(promises)
    }

    // If more items, schedule next batch
    if (pendingItems.current.length > 0) {
      batchingTimer.current = setTimeout(batchExecute, delay)
    }
  }, [delay, maxSize])

  const addToBatch = useCallback((key: string, requestFn: () => Promise<T>) => {
    // If request is already pending, return existing promise
    if (pendingRequests.current.has(key)) {
      console.log(`[Batch] Request ${key} already in progress`)
      return pendingRequests.current.get(key)!
    }

    // Add to pending items
    pendingItems.current.push({ key, requestFn })
    console.log(`[Batch] Added ${key} to queue (${pendingItems.current.length} pending)`)

    // Clear existing timer
    if (batchingTimer.current) {
      clearTimeout(batchingTimer.current)
    }

    // Schedule batch execution
    batchingTimer.current = setTimeout(batchExecute, delay)

    // Return promise that will resolve when batch executes
    return new Promise((resolve, reject) => {
      const checkProcessed = setInterval(() => {
        const promise = pendingRequests.current.get(key)
        if (!promise) {
          clearInterval(checkProcessed)
          // Check if result is ready
          const storedPromise = pendingRequests.current.get(key)
          if (!storedPromise) {
            reject(new Error(`Request ${key} was not processed`))
          }
        }
      }, 50)
    })
  }, [batchExecute, delay])

  const clearBatch = useCallback(() => {
    console.log('[Batch] Clearing all pending requests')
    pendingItems.current = []
    pendingRequests.current.clear()
    if (batchingTimer.current) {
      clearTimeout(batchingTimer.current)
    }
  }, [])

  const getBatchStatus = useCallback(() => {
    return {
      pending: pendingRequests.current.size,
      queued: pendingItems.current.length,
      total: pendingRequests.current.size + pendingItems.current.length
    }
  }, [])

  return {
    batchRequest: addToBatch,
    clearBatch,
    getBatchStatus
  }
}

// Separate batch processor for API calls
export function useAPIBatching() {
  const apiCache = useRef(new Map<string, { data: any; timestamp: number }>())
  const CACHE_DURATION = 30 * 1000 // 30 seconds

  const fetchWithBatching = useCallback(async <T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> => {
    const cacheKey = `${endpoint}:${JSON.stringify(options)}`

    // Check cache
    const cached = apiCache.current.get(cacheKey)
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      console.log(`[API Batch] Cache HIT for ${endpoint}`)
      return cached.data as T
    }

    console.log(`[API Batch] Cache MISS for ${endpoint}`)

    // Fetch from API
    const response = await fetch(`/api${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'API request failed')
    }

    const data = await response.json()

    // Update cache
    apiCache.current.set(cacheKey, {
      data,
      timestamp: Date.now()
    })

    // Clean old cache entries periodically
    if (apiCache.current.size > 100) {
      const now = Date.now()
      for (const [key, value] of apiCache.current.entries()) {
        if (now - value.timestamp > CACHE_DURATION * 10) {
          apiCache.current.delete(key)
        }
      }
    }

    return data as T
  }, [])

  const clearAPICache = useCallback(() => {
    console.log('[API Batch] Clearing API cache')
    apiCache.current.clear()
  }, [])

  const getCacheStats = useCallback(() => {
    return {
      size: apiCache.current.size,
      entries: Array.from(apiCache.current.entries())
    }
  }, [])

  return {
    fetchWithBatching,
    clearAPICache,
    getCacheStats
  }
}
