'use client'

import { useEffect, useState, useRef } from 'react'
import { io, Socket } from 'socket.io-client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Terminal, Play, Square, Globe, Code2, Zap, Cpu, Video, Mic, Sparkles, Wand2, Film } from 'lucide-react'
import { toast } from 'sonner'
import ReactMarkdown from 'react-markdown'

interface TerminalOutput {
  output: string
  type: 'stdout' | 'stderr' | 'info'
}

interface WebBuilderFiles {
  filename: string
  content: string
}

export default function AdvancedFeaturesPanel({
  activeCode,
  activeLanguage
}: {
  activeCode: string
  activeLanguage: string
}) {
  const [terminalSocket, setTerminalSocket] = useState<Socket | null>(null)
  const [webBuilderSocket, setWebBuilderSocket] = useState<Socket | null>(null)
  const [terminalConnected, setTerminalConnected] = useState(false)
  const [webBuilderConnected, setWebBuilderConnected] = useState(false)
  const [terminalOutput, setTerminalOutput] = useState<TerminalOutput[]>([])
  const [isExecuting, setIsExecuting] = useState(false)

  // Web Builder state
  const [webBuilderPrompt, setWebBuilderPrompt] = useState('')
  const [webBuilderModel, setWebBuilderModel] = useState('glm-v')
  const [webBuilderOutput, setWebBuilderOutput] = useState('')
  const [webBuilderFiles, setWebBuilderFiles] = useState<WebBuilderFiles[]>([])
  const [isGenerating, setIsGenerating] = useState(false)

  const terminalEndRef = useRef<HTMLDivElement>(null)
  const webBuilderEndRef = useRef<HTMLDivElement>(null)

  // AI Models configuration
  const aiModels = {
    'glm-v': { name: 'GLM-V', description: 'General purpose model' },
    'glm-4.5': { name: 'GLM-4.5', description: 'Advanced model for complex tasks' },
    'kaleido': { name: 'Kaleido', description: 'Multimodal model for visual & code' }
  }

  // Initialize terminal socket
  useEffect(() => {
    const socket = io('/?XTransformPort=3004', {
      transports: ['websocket']
    })

    socket.on('connect', () => {
      console.log('Terminal connected')
      setTerminalConnected(true)
      toast.success('Terminal connected!')
    })

    socket.on('disconnect', () => {
      console.log('Terminal disconnected')
      setTerminalConnected(false)
    })

    socket.on('terminal:output', (data: TerminalOutput) => {
      setTerminalOutput(prev => [...prev, data])
    })

    socket.on('terminal:complete', (data: any) => {
      setIsExecuting(false)
      terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    })

    socket.on('terminal:error', (data: { error: string }) => {
      setIsExecuting(false)
      setTerminalOutput(prev => [...prev, { output: `Error: ${data.error}`, type: 'stderr' }])
      toast.error(`Terminal error: ${data.error}`)
    })

    socket.on('terminal:cleared', () => {
      setTerminalOutput([])
    })

    setTerminalSocket(socket)

    return () => {
      socket.disconnect()
    }
  }, [])

  // Initialize web builder socket
  useEffect(() => {
    const socket = io('/?XTransformPort=3005', {
      transports: ['websocket']
    })

    socket.on('connect', () => {
      console.log('Web Builder connected')
      setWebBuilderConnected(true)
      toast.success('Web Builder connected!')
    })

    socket.on('disconnect', () => {
      console.log('Web Builder disconnected')
      setWebBuilderConnected(false)
    })

    socket.on('web-builder:chunk', (data: { chunk: string }) => {
      setWebBuilderOutput(prev => prev + data.chunk)
      webBuilderEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    })

    socket.on('web-builder:complete', (data: { content: string; files: WebBuilderFiles[]; model: string }) => {
      setIsGenerating(false)
      setWebBuilderFiles(data.files)
      toast.success(`Web files generated with ${aiModels[data.model as keyof typeof aiModels]?.name || data.model}!`)
    })

    socket.on('web-builder:error', (data: { error: string }) => {
      setIsGenerating(false)
      toast.error(`Web Builder error: ${data.error}`)
    })

    setWebBuilderSocket(socket)

    return () => {
      socket.disconnect()
    }
  }, [])

  // Execute code in terminal
  const handleExecute = () => {
    if (!terminalSocket || !terminalConnected || !activeCode) {
      toast.error('Terminal not connected or no code to execute')
      return
    }

    setIsExecuting(true)
    setTerminalOutput([])

    terminalSocket.emit('terminal:execute', {
      language: activeLanguage,
      code: activeCode
    })
  }

  // Cancel terminal execution
  const handleCancelExecution = () => {
    if (!terminalSocket || !terminalConnected) return

    terminalSocket.emit('terminal:cancel')
    setIsExecuting(false)
  }

  // Clear terminal
  const handleClearTerminal = () => {
    if (!terminalSocket || !terminalConnected) {
      setTerminalOutput([])
      return
    }

    terminalSocket.emit('terminal:clear')
  }

  // Generate web files
  const handleGenerateWebFiles = () => {
    if (!webBuilderSocket || !webBuilderConnected || !webBuilderPrompt.trim()) {
      toast.error('Web Builder not connected or no prompt provided')
      return
    }

    setIsGenerating(true)
    setWebBuilderOutput('')
    setWebBuilderFiles([])

    webBuilderSocket.emit('web-builder:generate', {
      prompt: webBuilderPrompt,
      model: webBuilderModel
    })
  }

  // Download web file
  const handleDownloadFile = (file: WebBuilderFiles) => {
    const blob = new Blob([file.content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = file.filename
    a.click()
    URL.revokeObjectURL(url)
    toast.success(`Downloaded ${file.filename}`)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cpu className="w-5 h-5" />
            Advanced AI Services
          </CardTitle>
          <CardDescription>
            Real terminal execution and web file generation powered by GLM-V, GLM-4.5, and Kaleido
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="terminal" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="terminal" className="flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                Terminal
              </TabsTrigger>
              <TabsTrigger value="web-builder" className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                Web Builder
              </TabsTrigger>
            </TabsList>

            {/* Terminal Tab */}
            <TabsContent value="terminal" className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {terminalConnected ? (
                    <Badge variant="default">Connected</Badge>
                  ) : (
                    <Badge variant="destructive">Disconnected</Badge>
                  )}
                  <span className="text-sm text-muted-foreground">
                    Port 3004
                  </span>
                </div>
                <div className="flex gap-2">
                  {!isExecuting ? (
                    <Button size="sm" onClick={handleExecute} disabled={!terminalConnected || !activeCode}>
                      <Play className="w-4 h-4 mr-2" />
                      Execute
                    </Button>
                  ) : (
                    <Button size="sm" variant="destructive" onClick={handleCancelExecution}>
                      <Square className="w-4 h-4 mr-2" />
                      Cancel
                    </Button>
                  )}
                  <Button size="sm" variant="outline" onClick={handleClearTerminal}>
                    Clear
                  </Button>
                </div>
              </div>

              <div className="bg-black text-green-400 font-mono text-sm rounded-lg overflow-hidden">
                <ScrollArea className="h-96 p-4">
                  {terminalOutput.length === 0 ? (
                    <div className="text-muted-foreground">
                      {'>'} Terminal ready. Execute code to see output...
                    </div>
                  ) : (
                    <>
                      {terminalOutput.map((line, index) => (
                        <div
                          key={index}
                          className={`mb-1 ${
                            line.type === 'stderr' ? 'text-red-400' :
                            line.type === 'info' ? 'text-blue-400' :
                            ''
                          }`}
                        >
                          {line.output}
                        </div>
                      ))}
                      <div ref={terminalEndRef} />
                    </>
                  )}
                </ScrollArea>
              </div>
            </TabsContent>

            {/* Web Builder Tab */}
            <TabsContent value="web-builder" className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {webBuilderConnected ? (
                    <Badge variant="default">Connected</Badge>
                  ) : (
                    <Badge variant="destructive">Disconnected</Badge>
                  )}
                  <span className="text-sm text-muted-foreground">
                    Port 3005
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>AI Model</Label>
                  <Select value={webBuilderModel} onValueChange={setWebBuilderModel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(aiModels).map(([key, model]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex flex-col">
                            <div className="flex items-center gap-2">
                              <Zap className="w-4 h-4" />
                              <span className="font-medium">{model.name}</span>
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {model.description}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    placeholder="Describe the web page or application you want to build..."
                    value={webBuilderPrompt}
                    onChange={(e) => setWebBuilderPrompt(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button
                  className="w-full"
                  onClick={handleGenerateWebFiles}
                  disabled={!webBuilderConnected || !webBuilderPrompt.trim() || isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <Zap className="w-4 h-4 mr-2 animate-pulse" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Code2 className="w-4 h-4 mr-2" />
                      Generate Web Files
                    </>
                  )}
                </Button>
              </div>

              {webBuilderFiles.length > 0 && (
                <div className="space-y-2">
                  <Label>Generated Files</Label>
                  <div className="space-y-2">
                    {webBuilderFiles.map((file, index) => (
                      <div
                        key={index}
                        className="border rounded-lg p-4 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="secondary">{file.filename}</Badge>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDownloadFile(file)}
                          >
                            Download
                          </Button>
                        </div>
                        <pre className="text-sm bg-muted p-3 rounded overflow-x-auto max-h-64">
                          {file.content}
                        </pre>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {webBuilderOutput && webBuilderFiles.length === 0 && (
                <div className="border rounded-lg p-4">
                  <Label>AI Response</Label>
                  <ScrollArea className="h-64 mt-2">
                    <div className="text-sm prose prose-sm dark:prose-invert max-w-none">
                      <ReactMarkdown>{webBuilderOutput}</ReactMarkdown>
                    </div>
                    <div ref={webBuilderEndRef} />
                  </ScrollArea>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Repository Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code2 className="w-5 h-5" />
            AI Model Repositories
          </CardTitle>
          <CardDescription>
            Open-source AI models for app building
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {/* GLM-V */}
            <a
              href="https://github.com/zai-org/GLM-V"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" />
                <span className="font-medium">GLM-V</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                General purpose language model for versatile tasks
              </p>
            </a>

            {/* GLM-4.5 */}
            <a
              href="https://github.com/zai-org/GLM-4.5"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" />
                <span className="font-medium">GLM-4.5</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Advanced model for complex web development tasks
              </p>
            </a>

            {/* Kaleido */}
            <a
              href="https://github.com/zai-org/Kaleido"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-primary" />
                <span className="font-medium">Kaleido</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Multimodal model for visual and code generation
              </p>
            </a>

            {/* CogVideo */}
            <a
              href="https://github.com/zai-org/CogVideo"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Video className="w-4 h-4 text-primary" />
                <span className="font-medium">CogVideo</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Cognitive video generation model
              </p>
            </a>

            {/* GLM-TTS */}
            <a
              href="https://github.com/zai-org/GLM-TTS"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-primary" />
                <span className="font-medium">GLM-TTS</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Text-to-speech model for audio generation
              </p>
            </a>

            {/* Open-AutoGLM */}
            <a
              href="https://github.com/zai-org/Open-AutoGLM"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary" />
                <span className="font-medium">Open-AutoGLM</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Automated GLM model for various tasks
              </p>
            </a>

            {/* RealVideo */}
            <a
              href="https://github.com/zai-org/RealVideo"
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Film className="w-4 h-4 text-primary" />
                <span className="font-medium">RealVideo</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Real-time video generation and processing
              </p>
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
