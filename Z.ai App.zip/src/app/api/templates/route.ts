import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all templates
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')

    const templates = await db.template.findMany({
      where: category ? { category } : undefined,
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json({ success: true, templates })
  } catch (error) {
    console.error('Error fetching templates:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch templates' },
      { status: 500 }
    )
  }
}

// POST create new template
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, category, language, content } = body

    if (!name || !description || !category || !language || !content) {
      return NextResponse.json(
        { success: false, error: 'All template fields are required' },
        { status: 400 }
      )
    }

    const template = await db.template.create({
      data: {
        name,
        description,
        category,
        language,
        content
      }
    })

    return NextResponse.json({ success: true, template })
  } catch (error) {
    console.error('Error creating template:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create template' },
      { status: 500 }
    )
  }
}
