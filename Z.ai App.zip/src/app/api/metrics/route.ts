import { NextRequest, NextResponse } from 'next/server'

interface MetricEvent {
  eventName: string
  duration: number
  metadata?: Record<string, any>
  timestamp: number
}

const metricsStore = new Map<string, MetricEvent[]>()

export const runtime = 'edge'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { eventName, duration, metadata } = body

    if (!eventName || typeof duration !== 'number') {
      return NextResponse.json(
        { success: false, error: 'Invalid request body' },
        { status: 400 }
      )
    }

    const metric: MetricEvent = {
      eventName,
      duration,
      metadata: metadata || {},
      timestamp: Date.now()
    }

    if (!metricsStore.has(eventName)) {
      metricsStore.set(eventName, [])
    }
    metricsStore.get(eventName)!.push(metric)

    const allMetrics = metricsStore.get(eventName)!
    if (allMetrics.length > 100) {
      metricsStore.set(eventName, allMetrics.slice(-100))
    }

    console.log('[Metrics]', eventName, duration, 'ms', metadata)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('[Metrics] Error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to record metric' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const eventName = searchParams.get('event')

    let metrics: any[] = []

    if (eventName) {
      const eventMetrics = metricsStore.get(eventName) || []
      metrics = eventMetrics
    } else {
      metrics = Array.from(metricsStore.entries()).map(([event, events]) => ({
        event,
        count: events.length,
        avgDuration: events.reduce((sum, e) => sum + e.duration, 0) / events.length,
        minDuration: Math.min(...events.map(e => e.duration)),
        maxDuration: Math.max(...events.map(e => e.duration)),
        lastOccurrence: events[events.length - 1]?.timestamp
      }))
    }

    return NextResponse.json({
      success: true,
      metrics,
      timestamp: Date.now()
    })
  } catch (error) {
    console.error('[Metrics] Error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to retrieve metrics' },
      { status: 500 }
    )
  }
}
