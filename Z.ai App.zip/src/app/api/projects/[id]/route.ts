import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET single project
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const project = await db.project.findUnique({
      where: { id: params.id },
      include: {
        files: {
          orderBy: {
            order: 'asc'
          }
        },
        templates: true
      }
    })

    if (!project) {
      return NextResponse.json(
        { success: false, error: 'Project not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, project })
  } catch (error) {
    console.error('Error fetching project:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch project' },
      { status: 500 }
    )
  }
}

// PUT update project
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { name, description, files } = body

    // Update project basic info
    const project = await db.project.update({
      where: { id: params.id },
      data: {
        name,
        description
      }
    })

    // If files are provided, update them
    if (files && Array.isArray(files)) {
      // Delete existing files
      await db.file.deleteMany({
        where: { projectId: params.id }
      })

      // Create new files
      await db.file.createMany({
        data: files.map((file: any, index: number) => ({
          projectId: params.id,
          name: file.name,
          language: file.language,
          content: file.content,
          order: index
        }))
      })
    }

    // Fetch updated project with files
    const updatedProject = await db.project.findUnique({
      where: { id: params.id },
      include: {
        files: {
          orderBy: {
            order: 'asc'
          }
        }
      }
    })

    return NextResponse.json({ success: true, project: updatedProject })
  } catch (error) {
    console.error('Error updating project:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update project' },
      { status: 500 }
    )
  }
}

// DELETE project
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.project.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ success: true, message: 'Project deleted successfully' })
  } catch (error) {
    console.error('Error deleting project:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete project' },
      { status: 500 }
    )
  }
}
