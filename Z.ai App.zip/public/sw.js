const CACHE_NAME = 'ai-app-builder-v1'
const ASSETS_TO_CACHE = [
  '/',
  '/_next/static',
  '/api/projects',
  '/api/templates',
  '/api/ai-assistant',
]

// Cache strategies
const CACHE_DURATION = 60 * 60 * 1000 // 1 hour
const API_CACHE_DURATION = 5 * 60 * 1000 // 5 minutes

// Install event - cache assets
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing...')
  
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Caching app shell...')
      
      // Cache static assets
      return cache.addAll(
        ASSETS_TO_CACHE.map((url) => {
          return new Request(url, { cache: 'reload' })
        })
      )
    }).then(() => {
      console.log('[Service Worker] App shell cached')
      
      // Skip waiting to activate immediately
      self.skipWaiting()
    })
  )
})

// Activate event
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating...')
  
  // Clean up old caches
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((cacheName) => cacheName !== CACHE_NAME)
          .map((cacheName) => caches.delete(cacheName))
      ).then(() => {
        console.log('[Service Worker] Old caches cleaned')
        
        // Take control of open pages
        return self.clients.claim()
      })
    })
  )
})

// Fetch event - serve from cache with network fallback
self.addEventListener('fetch', (event) => {
  const { request } = event
  const url = new URL(request.url)

  // Only handle GET requests
  if (request.method !== 'GET') {
    return
  }

  // Don't cache API requests that need fresh data
  if (url.pathname.startsWith('/api/ai-assistant')) {
    event.respondWith(
      fetch(request).catch((error) => {
        return new Response('Network error', {
          status: 503,
          statusText: 'Service Unavailable'
        })
      })
    )
    return
  }

  // Cache strategy
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      // Return cached response if available
      if (cachedResponse) {
        console.log('[Service Worker] Serving from cache:', url.pathname)
        
        // Fetch fresh version in background
        fetch(request)
          .then((freshResponse) => {
            if (freshResponse.ok) {
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(request, freshResponse.clone())
              })
            }
          })
          .catch(() => {
            // Silent fail - cached version is still served
          })
        
        return cachedResponse
      }

      // No cached response - fetch from network
      console.log('[Service Worker] Fetching from network:', url.pathname)
      
      return fetch(request).then((networkResponse) => {
        // Cache successful responses
        if (networkResponse.ok) {
          const responseClone = networkResponse.clone()
          
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, responseClone)
          }).catch(() => {
            // Silent fail - response is still returned
          })
        }
        
        return networkResponse
      }).catch((error) => {
        // Network error - try serving from cache
        console.error('[Service Worker] Network error:', error)
        
        return caches.match(request).then((cachedResponse) => {
          if (cachedResponse) {
            console.log('[Service Worker] Serving from cache after network error')
            return cachedResponse
          }
          
          // No cached version available
          return new Response('Network error', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: {
              'Content-Type': 'text/plain'
            }
          })
        })
      })
    })
  )
})

// Message event - handle cache control
self.addEventListener('message', (event) => {
  const { type, payload } = event.data

  switch (type) {
    case 'SKIP_WAITING':
      self.skipWaiting()
      break

    case 'CLEAR_CACHE':
      caches.delete(CACHE_NAME).then(() => {
        console.log('[Service Worker] Cache cleared')
        // Re-open to install new cache
        self.clients.matchAll().then((clients) => {
          clients.forEach((client) => {
            client.postMessage({ type: 'CACHE_CLEARED' })
          })
        })
      })
      break

    case 'PRECACHE':
      caches.open(CACHE_NAME).then((cache) => {
        return Promise.all(
          payload.urls.map((url) => cache.add(new Request(url, { cache: 'reload' })))
        )
      }).then(() => {
        self.skipWaiting()
        console.log('[Service Worker] Precached', payload.urls.length, 'items')
      })
      break

    default:
      console.warn('[Service Worker] Unknown message type:', type)
  }
})

// Push notification support
self.addEventListener('push', (event) => {
  const { data } = event.json() || {}
  
  // Show notification
  self.registration.showNotification(data.title || 'AI App Builder', {
    body: data.body || '',
    icon: '/icon-192.png',
    badge: '/icon-72.png',
    tag: data.tag || 'default',
    data: {
      url: data.url || '/',
    },
    requireInteraction: true,
  })
})

// Sync event - handle background sync
self.addEventListener('sync', (event) => {
  console.log('[Service Worker] Sync event:', event.tag)
  
  const { tag } = event
  
  if (tag === 'sync-projects') {
    event.waitUntil(
      caches.open(CACHE_NAME).then((cache) => {
        // Sync projects with server
        return fetch('/api/projects', {
          headers: {
            'X-Sync-Event': 'true'
          }
        }).then((response) => {
          if (response.ok) {
            return response.json()
          }
          throw new Error('Sync failed')
        })
      }).then((data) => {
        // Update cache with synced projects
        return cache.put(
          new Request('/api/projects', { cache: 'reload' }),
          new Response(JSON.stringify(data))
        )
      })
    })
  )
})
