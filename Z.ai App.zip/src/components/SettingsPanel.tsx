'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Settings,
  Monitor,
  Palette,
  Zap,
  Database,
  Globe,
  Code2,
  Save,
  RotateCcw
} from 'lucide-react'
import { toast } from 'sonner'

interface SettingsPanelProps {
  onSettingsChange?: (settings: any) => void
}

export default function SettingsPanel({ onSettingsChange }: SettingsPanelProps) {
  // Theme settings
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('dark')
  const [accentColor, setAccentColor] = useState('primary')

  // Editor settings
  const [fontSize, setFontSize] = useState(14)
  const [tabSize, setTabSize] = useState(2)
  const [showLineNumbers, setShowLineNumbers] = useState(true)
  const [wordWrap, setWordWrap] = useState(true)
  const [minimap, setMinimap] = useState(true)

  // Terminal settings
  const [terminalFontSize, setTerminalFontSize] = useState(12)
  const [terminalTheme, setTerminalTheme] = useState<'dark' | 'light'>('dark')
  const [autoScroll, setAutoScroll] = useState(true)

  // AI settings
  const [aiTemperature, setAiTemperature] = useState(0.7)
  const [maxTokens, setMaxTokens] = useState(2000)
  const [deepThinking, setDeepThinking] = useState(false)
  const [streaming, setStreaming] = useState(true)

  // Project settings
  const [autoSave, setAutoSave] = useState(true)
  const [autoSaveInterval, setAutoSaveInterval] = useState(60)
  const [autoCompile, setAutoCompile] = useState(false)

  // Panel visibility
  const [hideTerminal, setHideTerminal] = useState(false)
  const [hideAIChat, setHideAIChat] = useState(false)
  const [hideTemplates, setHideTemplates] = useState(false)
  const [hideRepositories, setHideRepositories] = useState(false)

  const handleSave = () => {
    const settings = {
      theme,
      accentColor,
      fontSize,
      tabSize,
      showLineNumbers,
      wordWrap,
      minimap,
      terminalFontSize,
      terminalTheme,
      autoScroll,
      aiTemperature,
      maxTokens,
      deepThinking,
      streaming,
      autoSave,
      autoSaveInterval,
      autoCompile,
      hideTerminal,
      hideAIChat,
      hideTemplates,
      hideRepositories
    }

    // Save to localStorage
    localStorage.setItem('ai-app-builder-settings', JSON.stringify(settings))

    if (onSettingsChange) {
      onSettingsChange(settings)
    }

    toast.success('Settings saved!')
  }

  const handleReset = () => {
    if (confirm('Reset all settings to defaults?')) {
      localStorage.removeItem('ai-app-builder-settings')
      setTheme('dark')
      setAccentColor('primary')
      setFontSize(14)
      setTabSize(2)
      setShowLineNumbers(true)
      setWordWrap(true)
      setMinimap(true)
      setTerminalFontSize(12)
      setTerminalTheme('dark')
      setAutoScroll(true)
      setAiTemperature(0.7)
      setMaxTokens(2000)
      setDeepThinking(false)
      setStreaming(true)
      setAutoSave(true)
      setAutoSaveInterval(60)
      setAutoCompile(false)
      setHideTerminal(false)
      setHideAIChat(false)
      setHideTemplates(false)
      setHideRepositories(false)

      toast.success('Settings reset to defaults!')
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Settings
        </CardTitle>
        <CardDescription>
          Configure your AI App Builder preferences
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px] pr-4">
          <div className="space-y-6">
            {/* Theme Settings */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Theme</h3>
              </div>
              <div className="grid grid-cols-2 gap-4 pl-6">
                <div className="space-y-2">
                  <Label>Theme</Label>
                  <Select value={theme} onValueChange={(v: any) => setTheme(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Accent Color</Label>
                  <Select value={accentColor} onValueChange={setAccentColor}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="primary">Primary</SelectItem>
                      <SelectItem value="secondary">Secondary</SelectItem>
                      <SelectItem value="accent">Accent</SelectItem>
                      <SelectItem value="muted">Muted</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <Separator />

            {/* Editor Settings */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Editor</h3>
              </div>
              <div className="space-y-3 pl-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Font Size ({fontSize}px)</Label>
                    <Input
                      type="range"
                      min={10}
                      max={24}
                      value={fontSize}
                      onChange={(e) => setFontSize(parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Tab Size ({tabSize} spaces)</Label>
                    <Input
                      type="range"
                      min={2}
                      max={8}
                      value={tabSize}
                      onChange={(e) => setTabSize(parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <Label>Line Numbers</Label>
                    <Switch
                      checked={showLineNumbers}
                      onCheckedChange={setShowLineNumbers}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Word Wrap</Label>
                    <Switch
                      checked={wordWrap}
                      onCheckedChange={setWordWrap}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <Label>Show Minimap</Label>
                  <Switch
                    checked={minimap}
                    onCheckedChange={setMinimap}
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Terminal Settings */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Monitor className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Terminal</h3>
              </div>
              <div className="space-y-3 pl-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Font Size ({terminalFontSize}px)</Label>
                    <Input
                      type="range"
                      min={10}
                      max={20}
                      value={terminalFontSize}
                      onChange={(e) => setTerminalFontSize(parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Terminal Theme</Label>
                    <Select value={terminalTheme} onValueChange={(v: any) => setTerminalTheme(v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="light">Light</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <Label>Auto Scroll to Bottom</Label>
                  <Switch
                    checked={autoScroll}
                    onCheckedChange={setAutoScroll}
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* AI Settings */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">AI Configuration</h3>
              </div>
              <div className="space-y-3 pl-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Temperature ({aiTemperature})</Label>
                    <Input
                      type="range"
                      min={0}
                      max={2}
                      step={0.1}
                      value={aiTemperature}
                      onChange={(e) => setAiTemperature(parseFloat(e.target.value))}
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Max Tokens ({maxTokens})</Label>
                    <Input
                      type="range"
                      min={500}
                      max={4000}
                      step={100}
                      value={maxTokens}
                      onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <Label>Deep Thinking Mode</Label>
                    <Switch
                      checked={deepThinking}
                      onCheckedChange={setDeepThinking}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Enable Streaming</Label>
                    <Switch
                      checked={streaming}
                      onCheckedChange={setStreaming}
                    />
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Project Settings */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Project</h3>
              </div>
              <div className="space-y-3 pl-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <Label>Auto Save</Label>
                    <Switch
                      checked={autoSave}
                      onCheckedChange={setAutoSave}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Auto Compile</Label>
                    <Switch
                      checked={autoCompile}
                      onCheckedChange={setAutoCompile}
                    />
                  </div>
                </div>
                {autoSave && (
                  <div className="space-y-2">
                    <Label>Auto Save Interval ({autoSaveInterval}s)</Label>
                    <Input
                      type="range"
                      min={10}
                      max={300}
                      step={10}
                      value={autoSaveInterval}
                      onChange={(e) => setAutoSaveInterval(parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Panel Visibility */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Panel Visibility</h3>
              </div>
              <div className="space-y-2 pl-6">
                <div className="flex items-center justify-between">
                  <Label>Hide Terminal Panel</Label>
                  <Switch
                    checked={hideTerminal}
                    onCheckedChange={setHideTerminal}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Hide AI Chat Panel</Label>
                  <Switch
                    checked={hideAIChat}
                    onCheckedChange={setHideAIChat}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Hide Templates Panel</Label>
                  <Switch
                    checked={hideTemplates}
                    onCheckedChange={setHideTemplates}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Hide Repositories Panel</Label>
                  <Switch
                    checked={hideRepositories}
                    onCheckedChange={setHideRepositories}
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Actions */}
            <div className="flex gap-2 pt-4">
              <Button onClick={handleSave} className="flex-1">
                <Save className="w-4 h-4 mr-2" />
                Save Settings
              </Button>
              <Button variant="outline" onClick={handleReset}>
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset to Defaults
              </Button>
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
