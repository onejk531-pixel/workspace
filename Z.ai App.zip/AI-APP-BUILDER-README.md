# AI App Builder

An intelligent, AI-powered application builder that integrates open-source AI models for code generation, debugging, optimization, and more.

## 🚀 Features

### Code Generation
- Generate code from natural language descriptions
- Support for multiple programming languages (TypeScript, JavaScript, Python, etc.)
- Automatic code formatting and syntax highlighting
- Intelligent code suggestions and completions

### AI-Powered Debugging
- Identify and fix bugs automatically
- Get detailed explanations of issues
- Receive corrected code with explanations
- Best practices and error handling suggestions

### Code Explanation
- Understand complex code with AI-powered explanations
- Break down code into understandable segments
- Learn coding concepts and patterns
- Get documentation-style explanations

### Code Optimization
- Improve code performance and efficiency
- Apply best practices and design patterns
- Refactor code for better readability
- Memory and performance optimization suggestions

### Test Generation
- Automatically generate comprehensive unit tests
- Cover edge cases and error scenarios
- Generate test code for various testing frameworks
- Ensure code quality and reliability

### Multi-File Project Support
- Manage multiple files in a single project
- Easy file creation, deletion, and switching
- Project structure visualization
- File-specific language detection

### Interactive Terminal
- Simulated code execution environment
- Real-time output display
- Command history tracking
- Clear terminal functionality

### Natural Language Interface
- Chat with AI in natural language
- Context-aware conversations
- Multi-turn dialogue support
- Intelligent response generation

## 🛠️ Tech Stack

- **Frontend Framework**: Next.js 15 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui (Radix UI primitives)
- **Code Editor**: Monaco Editor (VS Code's editor)
- **AI Integration**: z-ai-web-dev-sdk
- **State Management**: React hooks
- **Icons**: Lucide React

## 🎯 AI Capabilities

The app builder leverages powerful open-source AI models for various tasks:

### Models Used
- **LLM (Large Language Model)**: For code generation, debugging, and explanations
- Future support planned for:
  - **Qwen 2.5/3**: High-accuracy code generation
  - **DeepSeek R1**: Fast prototyping
  - **LLaMA 4**: Complex multi-file projects
  - **Gemma 3**: UI building and scripting
  - **GPT-OSS 120B**: Full-project code generation

### AI Modes

1. **Generate Mode**
   - Create new code from descriptions
   - Generate functions and classes
   - Build complete modules and components
   - Support various programming languages

2. **Debug Mode**
   - Identify bugs and issues
   - Provide corrected code
   - Explain the root cause
   - Suggest prevention strategies

3. **Explain Mode**
   - Break down complex code
   - Explain algorithms and logic
   - Provide learning resources
   - Clarify code purpose and function

4. **Optimize Mode**
   - Improve performance
   - Apply best practices
   - Refactor for readability
   - Reduce code complexity

5. **Test Mode**
   - Generate unit tests
   - Create test cases
   - Cover edge cases
   - Suggest testing strategies

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx              # Main app builder interface
│   ├── layout.tsx            # Root layout with providers
│   ├── globals.css           # Global styles
│   └── api/
│       └── ai-assistant/
│           └── route.ts      # AI API endpoints
├── components/
│   └── ui/                   # shadcn/ui components
├── lib/
│   ├── utils.ts              # Utility functions
│   └── db.ts                 # Database client
└── hooks/
    └── use-toast.ts          # Toast notifications
```

## 🚦 Getting Started

### Prerequisites
- Node.js 18+ or Bun
- Modern web browser

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   bun install
   ```

3. Run the development server:
   ```bash
   bun run dev
   ```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## 💡 Usage Guide

### Creating Code

1. Select **Generate Code** mode in the AI Assistant panel
2. Describe what you want to create in natural language
3. Click **Generate** or press Enter
4. The AI will generate code and update your editor

### Debugging Code

1. Select **Debug** mode
2. Describe the issue or paste the problematic code
3. Click **Generate** to get the fix
4. The AI will provide corrected code with explanations

### Explaining Code

1. Select **Explain** mode
2. Ensure the code you want to understand is in the editor
3. Click **Generate** to get a detailed explanation

### Optimizing Code

1. Select **Optimize** mode
2. Have your code in the editor
3. Click **Generate** to get optimized code
4. Review the improvements and explanations

### Generating Tests

1. Select **Generate Tests** mode
2. Have the code you want to test in the editor
3. Click **Generate** to get comprehensive tests
4. Copy and run the tests in your testing framework

### Managing Files

- **Create New File**: Click the + button in the Files section
- **Delete File**: Click the trash icon on a file tab
- **Switch Files**: Click on different file tabs
- **Download File**: Click the Download button to save your work

### Running Code

1. Click the **Run** button to simulate code execution
2. View the output in the Terminal panel
3. Clear the terminal when needed with the **Clear** button

## 🎨 Features Overview

### Editor Features
- **Syntax Highlighting**: Automatic language detection
- **Code Folding**: Collapse code sections
- **Minimap**: Overview of your code
- **Auto-indentation**: Smart indentation
- **Line Numbers**: Easy code navigation
- **Word Wrap**: Better readability

### AI Assistant Features
- **Natural Language Interface**: Chat with AI naturally
- **Context-Aware Responses**: Understands your project
- **Multi-Mode Support**: Different AI capabilities
- **Real-time Feedback**: Instant AI responses
- **Code Updates**: Automatic editor updates

### Project Management
- **Multi-File Support**: Work on multiple files
- **Easy Navigation**: Quick file switching
- **Export Options**: Download individual files
- **Copy to Clipboard**: Quick code copying

## 🔧 API Endpoints

### POST /api/ai-assistant

Process AI requests for code generation, debugging, etc.

**Request Body:**
```json
{
  "message": "string",
  "mode": "generate" | "debug" | "explain" | "optimize" | "test",
  "code": "string",
  "language": "string"
}
```

**Response:**
```json
{
  "success": true,
  "response": "string",
  "code": "string | undefined"
}
```

## 🎯 Best Practices

1. **Be Specific**: Provide clear, detailed descriptions
2. **Iterate**: Refine your requests based on AI responses
3. **Review Code**: Always review generated code
4. **Test Thoroughly**: Verify code in your environment
5. **Use Modes**: Choose the appropriate AI mode for your task
6. **Context Matters**: The AI uses your current code as context

## 🚀 Future Enhancements

- [ ] Real-time collaboration
- [ ] Project templates
- [ ] Git integration
- [ ] Deploy directly from the builder
- [ ] More AI models integration
- [ ] Voice command support
- [ ] Multi-language UI
- [ ] Dark/light theme toggle
- [ ] Keyboard shortcuts
- [ ] Code snippets library
- [ ] AI-powered refactoring suggestions
- [ ] Performance profiling integration

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- Built with [Next.js](https://nextjs.org/)
- UI components from [shadcn/ui](https://ui.shadcn.com/)
- Code editor powered by [Monaco Editor](https://microsoft.github.io/monaco-editor/)
- AI capabilities from [z-ai-web-dev-sdk](https://z.ai)

## 📞 Support

For support and questions, please open an issue on the repository.

---

**Built with ❤️ using Open Source AI**
