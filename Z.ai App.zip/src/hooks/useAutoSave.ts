'use client'

import { useEffect, useRef, useCallback } from 'react'
import { useDebouncedCallback } from '@/hooks/useDebounce'
import { toast } from 'sonner'

interface AutoSaveOptions {
  enabled?: boolean
  delay?: number
  onSaveStart?: () => void
  onSaveSuccess?: () => void
  onSaveError?: (error: Error) => void
}

export function useAutoSave<T>(
  data: T,
  saveFn: (data: T) => Promise<void> | void,
  options: AutoSaveOptions = {}
) {
  const {
    enabled = true,
    delay = 2000,
    onSaveStart,
    onSaveSuccess,
    onSaveError
  } = options

  const lastSavedData = useRef<T>(data)
  const isSaving = useRef(false)
  const timeoutRef = useRef<NodeJS.Timeout>()

  const debouncedSave = useCallback(async () => {
    // Don't save if disabled or already saving
    if (!enabled || isSaving.current) {
      return
    }

    // Check if data has changed
    if (JSON.stringify(data) === JSON.stringify(lastSavedData.current)) {
      console.log('[AutoSave] No changes detected')
      return
    }

    isSaving.current = true
    onSaveStart?.()

    try {
      // Clear existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }

      // Set new timeout
      timeoutRef.current = setTimeout(async () => {
        try {
          await saveFn(data)
          lastSavedData.current = data
          onSaveSuccess?.()
          toast.success('Auto-saved!')
        } catch (error) {
          console.error('[AutoSave] Error:', error)
          onSaveError?.(error as Error)
          toast.error('Failed to auto-save')
        } finally {
          isSaving.current = false
        }
      }, delay)

    } catch (error) {
      console.error('[AutoSave] Unexpected error:', error)
      isSaving.current = false
    }
  }, [data, saveFn, enabled, delay, onSaveStart, onSaveSuccess, onSaveError])

  // Clean up timeout on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  return {
    debouncedSave,
    isSaving: isSaving.current,
    lastSaved: lastSavedData.current,
    forceSave: useCallback(async () => {
      // Clear timeout and save immediately
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
      
      if (!enabled) {
        toast.error('Auto-save is disabled')
        return
      }

      try {
        isSaving.current = true
        onSaveStart?.()
        
        await saveFn(data)
        lastSavedData.current = data
        onSaveSuccess?.()
        toast.success('Saved!')
      } catch (error) {
        console.error('[AutoSave] Force save error:', error)
        onSaveError?.(error as Error)
        toast.error('Failed to save')
      } finally {
        isSaving.current = false
      }
    }, [saveFn, data, enabled, onSaveStart, onSaveSuccess, onSaveError])
  }
}
