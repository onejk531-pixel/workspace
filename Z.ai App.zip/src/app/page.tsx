'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Code2,
  Sparkles,
  Bug,
  FileText,
  Terminal,
  Plus,
  Trash2,
  Download,
  Copy,
  MessageSquare,
  Settings,
  FolderOpen,
  FileCode,
  Zap,
  Save,
  FolderPlus,
  AlertCircle,
  LayoutTemplate,
  Layers,
  Search,
  Upload,
  Brain,
  Eye,
  EyeOff
} from 'lucide-react'
import Editor from '@monaco-editor/react'
import { toast } from 'sonner'
import ReactMarkdown from 'react-markdown'
import AdvancedFeaturesPanel from '@/components/AdvancedFeaturesPanel'
import SettingsPanel from '@/components/SettingsPanel'
import FileUploadPanel from '@/components/FileUploadPanel'
import FileSearchPanel from '@/components/FileSearchPanel'

interface File {
  id: string
  name: string
  language: string
  content: string
}

interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: Date
}

interface Project {
  id: string
  name: string
  description?: string
  files: File[]
  createdAt: Date
  updatedAt: Date
}

interface Template {
  id: string
  name: string
  description: string
  category: string
  language: string
  content: string
}

type AIMode = 'generate' | 'debug' | 'explain' | 'optimize' | 'test'
type ActivePanel = 'editor' | 'terminal' | 'web-builder' | 'file-upload' | 'file-search' | 'settings'

export default function AppBuilderPage() {
  const [files, setFiles] = useState<File[]>([
    {
      id: '1',
      name: 'main.ts',
      language: 'typescript',
      content: `// Welcome to AI App Builder!
// Start coding or use AI to generate code

function greet(name: string): string {
  return \`Hello, \${name}!\`;
}

console.log(greet('World'));`
    }
  ])
  const [activeFileId, setActiveFileId] = useState('1')

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'system',
      content: 'Welcome! I\'m your AI coding assistant. I can help you generate code, debug issues, explain concepts, and optimize your code. Choose a mode and let\'s start building!',
      timestamp: new Date()
    }
  ])
  const [userInput, setUserInput] = useState('')
  const [aiMode, setAiMode] = useState<AIMode>('generate')
  const [isProcessing, setIsProcessing] = useState(false)

  const [currentProject, setCurrentProject] = useState<Project | null>(null)
  const [projects, setProjects] = useState<Project[]>([])
  const [templates, setTemplates] = useState<Template[]>([])
  const [showProjectDialog, setShowProjectDialog] = useState(false)
  const [showTemplateDialog, setShowTemplateDialog] = useState(false)
  const [projectName, setProjectName] = useState('')
  const [projectDescription, setProjectDescription] = useState('')

  const [activePanel, setActivePanel] = useState<ActivePanel>('editor')
  const [showSidebar, setShowSidebar] = useState(true)

  const chatEndRef = useRef<HTMLDivElement>(null)
  const activeFile = files.find(f => f.id === activeFileId)

  useEffect(() => {
    loadProjects()
    loadTemplates()
  }, [])

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [chatMessages])

  const loadProjects = async () => {
    try {
      const response = await fetch('/api/projects')
      const data = await response.json()
      if (data.success) {
        setProjects(data.projects)
      }
    } catch (error) {
      console.error('Error loading projects:', error)
    }
  }

  const loadTemplates = async () => {
    try {
      const response = await fetch('/api/templates')
      const data = await response.json()
      if (data.success) {
        setTemplates(data.templates)
      }
    } catch (error) {
      console.error('Error loading templates:', error)
    }
  }

  const handleSaveProject = async () => {
    if (!projectName.trim()) {
      toast.error('Please enter a project name')
      return
    }

    try {
      const method = currentProject ? 'PUT' : 'POST'
      const url = currentProject
        ? `/api/projects/${currentProject.id}`
        : '/api/projects'

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: projectName,
          description: projectDescription,
          files
        })
      })

      const data = await response.json()

      if (data.success) {
        setCurrentProject(data.project)
        setShowProjectDialog(false)
        setProjectName('')
        setProjectDescription('')
        toast.success(currentProject ? 'Project updated!' : 'Project saved!')
        await loadProjects()
      } else {
        toast.error(data.error || 'Failed to save project')
      }
    } catch (error) {
      console.error('Error saving project:', error)
      toast.error('Failed to save project')
    }
  }

  const handleLoadProject = async (projectId: string) => {
    try {
      const response = await fetch(`/api/projects/${projectId}`)
      const data = await response.json()

      if (data.success) {
        setCurrentProject(data.project)
        setFiles(data.project.files)
        if (data.project.files.length > 0) {
          setActiveFileId(data.project.files[0].id)
        }
        setProjectName(data.project.name)
        setProjectDescription(data.project.description || '')
        toast.success('Project loaded!')
      }
    } catch (error) {
      console.error('Error loading project:', error)
      toast.error('Failed to load project')
    }
  }

  const handleDeleteProject = async (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation()

    if (!confirm('Are you sure you want to delete this project?')) {
      return
    }

    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        if (currentProject?.id === projectId) {
          setCurrentProject(null)
          setFiles([{
            id: '1',
            name: 'main.ts',
            language: 'typescript',
            content: '// Start coding...\n'
          }])
        }
        await loadProjects()
        toast.success('Project deleted!')
      }
    } catch (error) {
      console.error('Error deleting project:', error)
      toast.error('Failed to delete project')
    }
  }

  const handleApplyTemplate = async (templateId: string) => {
    const template = templates.find(t => t.id === templateId)
    if (!template) return

    const newFile: File = {
      id: Date.now().toString(),
      name: `${template.name.toLowerCase().replace(/\s+/g, '-')}.${template.language}`,
      language: template.language,
      content: template.content
    }

    setFiles([...files, newFile])
    setActiveFileId(newFile.id)
    setShowTemplateDialog(false)
    toast.success(`Template "${template.name}" applied!`)
  }

  const handleEditorChange = (value: string | undefined) => {
    if (!activeFile) return
    setFiles(files.map(f =>
      f.id === activeFileId ? { ...f, content: value || '' } : f
    ))
  }

  const handleCreateFile = () => {
    const newFile: File = {
      id: Date.now().toString(),
      name: `untitled.${activeFile?.language || 'ts'}`,
      language: activeFile?.language || 'typescript',
      content: '// New file\n'
    }
    setFiles([...files, newFile])
    setActiveFileId(newFile.id)
    toast.success('New file created')
  }

  const handleDeleteFile = (fileId: string) => {
    if (files.length === 1) {
      toast.error('Cannot delete the last file')
      return
    }
    const newFiles = files.filter(f => f.id !== fileId)
    setFiles(newFiles)
    if (activeFileId === fileId) {
      setActiveFileId(newFiles[0].id)
    }
    toast.success('File deleted')
  }

  const handleCopyCode = async () => {
    if (!activeFile) return
    await navigator.clipboard.writeText(activeFile.content)
    toast.success('Code copied to clipboard')
  }

  const handleDownloadFile = () => {
    if (!activeFile) return
    const blob = new Blob([activeFile.content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = activeFile.name
    a.click()
    URL.revokeObjectURL(url)
    toast.success('File downloaded')
  }

  const handleAIModeChange = (mode: AIMode) => {
    setAiMode(mode)
    toast.success(`Switched to ${mode} mode`)
  }

  const handleSendMessage = async () => {
    if (!userInput.trim()) return

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: userInput,
      timestamp: new Date()
    }

    setChatMessages([...chatMessages, userMessage])
    setUserInput('')
    setIsProcessing(true)

    try {
      const conversationHistory = chatMessages
        .filter(msg => msg.role !== 'system')
        .slice(-10)
        .map(msg => ({
          role: msg.role,
          content: msg.content
        }))

      const response = await fetch('/api/ai-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userInput,
          mode: aiMode,
          code: activeFile?.content || '',
          language: activeFile?.language || 'typescript',
          conversationHistory
        })
      })

      const data = await response.json()

      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response || 'Sorry, I encountered an error.',
        timestamp: new Date()
      }

      setChatMessages(prev => [...prev, aiMessage])

      if (data.code) {
        setFiles(files.map(f =>
          f.id === activeFileId ? { ...f, content: data.code } : f
        ))
        toast.success('Code updated by AI')
      }
    } catch (error) {
      console.error('Error:', error)
      toast.error('Failed to get AI response')
    } finally {
      setIsProcessing(false)
    }
  }

  const getModeDescription = (mode: AIMode): string => {
    switch (mode) {
      case 'generate':
        return 'Generate new code based on your description'
      case 'debug':
        return 'Find and fix bugs in your code'
      case 'explain':
        return 'Get detailed explanations of your code'
      case 'optimize':
        return 'Improve code performance and quality'
      case 'test':
        return 'Generate test cases for your code'
      default:
        return ''
    }
  }

  const getLanguageIcon = (language: string) => {
    return <FileCode className="w-4 h-4" />
  }

  const handleFilesUploaded = (newFiles: any[]) => {
    setFiles([...files, ...newFiles])
    toast.success(`${newFiles.length} file(s) added to project`)
  }

  const handleFileSelect = (fileId: string) => {
    setActiveFileId(fileId)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <h1 className="text-xl font-bold">AI App Builder</h1>
            </div>
            <Badge variant="secondary" className="ml-2">
              <Zap className="w-3 h-3 mr-1" />
              Powered by Open Source AI
            </Badge>
            {currentProject && (
              <Badge variant="outline" className="ml-2">
                <FolderOpen className="w-3 h-3 mr-1" />
                {currentProject.name}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSidebar(!showSidebar)}
            >
              {showSidebar ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
              {showSidebar ? 'Hide' : 'Show'} Panels
            </Button>

            <Select onValueChange={handleLoadProject}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Load project..." />
              </SelectTrigger>
              <SelectContent>
                {projects.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    <div className="flex items-center justify-between w-full gap-2">
                      <span className="flex-1">{project.name}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => handleDeleteProject(project.id, e)}
                        className="opacity-0 group-hover:opacity-100 hover:text-destructive"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" size="sm" onClick={() => setShowTemplateDialog(true)}>
              <LayoutTemplate className="w-4 h-4 mr-2" />
              Templates
            </Button>

            <Dialog open={showProjectDialog} onOpenChange={setShowProjectDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  {currentProject ? <><Save className="w-4 h-4 mr-2" />Save Project</> : <><FolderPlus className="w-4 h-4 mr-2" />New Project</>}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{currentProject ? 'Save Project' : 'Create New Project'}</DialogTitle>
                  <DialogDescription>
                    {currentProject ? 'Save your current work to an existing project' : 'Create a new project to organize your files'}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="project-name">Project Name</Label>
                    <Input
                      id="project-name"
                      value={projectName}
                      onChange={(e) => setProjectName(e.target.value)}
                      placeholder="My Awesome Project"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="project-description">Description (optional)</Label>
                    <Textarea
                      id="project-description"
                      value={projectDescription}
                      onChange={(e) => setProjectDescription(e.target.value)}
                      placeholder="Brief description of your project..."
                      rows={3}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowProjectDialog(false)}>Cancel</Button>
                  <Button onClick={handleSaveProject}>{currentProject ? 'Save' : 'Create'}</Button>
                </div>
              </DialogContent>
            </Dialog>

            <Button variant="outline" size="sm" onClick={() => setActivePanel('settings')}>
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {showSidebar && (
          <aside className="w-16 border-r bg-muted/30 flex flex-col">
            <div className="p-2 border-b">
              <Button variant={activePanel === 'editor' ? 'default' : 'ghost'} size="icon" onClick={() => setActivePanel('editor')} title="Code Editor">
                <Code2 className="w-5 h-5" />
              </Button>
            </div>
            <div className="p-2 border-b">
              <Button variant={activePanel === 'terminal' ? 'default' : 'ghost'} size="icon" onClick={() => setActivePanel('terminal')} title="Web Builder">
                <Zap className="w-5 h-5" />
              </Button>
            </div>
            <div className="p-2 border-b">
              <Button variant={activePanel === 'file-upload' ? 'default' : 'ghost'} size="icon" onClick={() => setActivePanel('file-upload')} title="File Upload">
                <Upload className="w-5 h-5" />
              </Button>
            </div>
            <div className="p-2 border-b">
              <Button variant={activePanel === 'file-search' ? 'default' : 'ghost'} size="icon" onClick={() => setActivePanel('file-search')} title="File Search">
                <Search className="w-5 h-5" />
              </Button>
            </div>
            <div className="mt-auto p-2">
              <Button variant={activePanel === 'settings' ? 'default' : 'ghost'} size="icon" onClick={() => setActivePanel('settings')} title="Settings">
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </aside>
        )}

        <main className="flex-1 overflow-auto">
          {activePanel === 'editor' && (
            <div className="container py-6 h-full">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-8rem)]">
                <div className="lg:col-span-2 flex flex-col gap-4">
                  <Card className="flex-1 flex flex-col">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FolderOpen className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm font-medium">Files</span>
                          <Button size="sm" variant="ghost" onClick={handleCreateFile}>
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline" onClick={handleCopyCode}>
                            <Copy className="w-4 h-4 mr-1" />Copy
                          </Button>
                          <Button size="sm" variant="outline" onClick={handleDownloadFile}>
                            <Download className="w-4 h-4 mr-1" />Download
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
                      <div className="flex items-center gap-1 p-2 border-b bg-muted/30">
                        {files.map(file => (
                          <div
                            key={file.id}
                            className={`flex items-center gap-2 px-3 py-2 rounded-t-md cursor-pointer text-sm transition-colors ${
                              activeFileId === file.id ? 'bg-background border-t-2 border-primary' : 'hover:bg-background/50'
                            }`}
                            onClick={() => setActiveFileId(file.id)}
                          >
                            {getLanguageIcon(file.language)}
                            <span>{file.name}</span>
                            {files.length > 1 && (
                              <button onClick={(e) => { e.stopPropagation(); handleDeleteFile(file.id) }} className="ml-1 hover:text-destructive">
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>

                      <div className="flex-1 overflow-hidden">
                        {activeFile ? (
                          <Editor
                            height="100%"
                            language={activeFile.language}
                            value={activeFile.content}
                            onChange={handleEditorChange}
                            theme="vs-dark"
                            options={{
                              minimap: { enabled: true },
                              fontSize: 14,
                              lineNumbers: 'on',
                              roundedSelection: false,
                              scrollBeyondLastLine: false,
                              readOnly: false,
                              automaticLayout: true,
                              tabSize: 2,
                              wordWrap: 'on',
                              formatOnPaste: true,
                              formatOnType: true
                            }}
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full text-muted-foreground">
                            No file selected
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card className="flex flex-col">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="w-5 h-5" />
                      AI Assistant
                    </CardTitle>
                    <CardDescription>Chat with AI to generate, debug, and explain code</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col p-0">
                    <div className="p-4 border-b">
                      <div className="mb-3">
                        <label className="text-sm font-medium mb-2 block">AI Mode</label>
                        <Select value={aiMode} onValueChange={(v: AIMode) => handleAIModeChange(v)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="generate">
                              <div className="flex items-center gap-2">
                                <Sparkles className="w-4 h-4" />Generate Code
                              </div>
                            </SelectItem>
                            <SelectItem value="debug">
                              <div className="flex items-center gap-2">
                                <Bug className="w-4 h-4" />Debug
                              </div>
                            </SelectItem>
                            <SelectItem value="explain">
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4" />Explain
                              </div>
                            </SelectItem>
                            <SelectItem value="optimize">
                              <div className="flex items-center gap-2">
                                <Zap className="w-4 h-4" />Optimize
                              </div>
                            </SelectItem>
                            <SelectItem value="test">
                              <div className="flex items-center gap-2">
                                <Copy className="w-4 h-4" />Generate Tests
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <p className="text-xs text-muted-foreground">{getModeDescription(aiMode)}</p>
                    </div>

                    <ScrollArea className="flex-1 p-4">
                      <div className="space-y-4">
                        {chatMessages.map((message) => (
                          <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[85%] rounded-lg p-3 ${
                              message.role === 'user' ? 'bg-primary text-primary-foreground' : message.role === 'system' ? 'bg-muted' : 'bg-muted'
                            }`}>
                              <div className="flex items-center gap-2 mb-2">
                                {message.role === 'user' && <span className="text-xs font-medium">You</span>}
                                {message.role === 'assistant' && (
                                  <span className="text-xs font-medium flex items-center gap-1">
                                    <Sparkles className="w-3 h-3" />AI
                                  </span>
                                )}
                              </div>
                              {message.role === 'assistant' ? (
                                <div className="text-sm prose prose-sm dark:prose-invert max-w-none">
                                  <ReactMarkdown>{message.content}</ReactMarkdown>
                                </div>
                              ) : (
                                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                              )}
                            </div>
                          </div>
                        ))}
                        {isProcessing && (
                          <div className="flex justify-start">
                            <div className="bg-muted rounded-lg p-3">
                              <div className="flex items-center gap-2">
                                <Sparkles className="w-4 h-4 animate-spin" />
                                <span className="text-sm">Thinking...</span>
                              </div>
                            </div>
                          </div>
                        )}
                        <div ref={chatEndRef} />
                      </div>
                    </ScrollArea>

                    <div className="p-4 border-t">
                      <Textarea
                        placeholder="Describe what you want to do..."
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault()
                            handleSendMessage()
                          }
                        }}
                        rows={3}
                        className="resize-none"
                      />
                      <div className="flex justify-between items-center mt-2">
                        <p className="text-xs text-muted-foreground">Press Enter to send, Shift+Enter for new line</p>
                        <Button onClick={handleSendMessage} disabled={isProcessing || !userInput.trim()} size="sm">
                          <Sparkles className="w-4 h-4 mr-2" />Generate
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activePanel === 'terminal' && (
            <div className="container py-6">
              <AdvancedFeaturesPanel
                activeCode={activeFile?.content || ''}
                activeLanguage={activeFile?.language || 'typescript'}
              />
            </div>
          )}

          {activePanel === 'file-upload' && (
            <div className="container py-6">
              <FileUploadPanel onFilesUploaded={handleFilesUploaded} />
            </div>
          )}

          {activePanel === 'file-search' && (
            <div className="container py-6">
              <FileSearchPanel
                files={files}
                onFileSelect={handleFileSelect}
              />
            </div>
          )}

          {activePanel === 'settings' && (
            <div className="container py-6">
              <SettingsPanel />
            </div>
          )}
        </main>
      </div>

      <footer className="border-t py-4 mt-auto bg-background">
        <div className="container flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>Powered by Open Source AI Models</span>
            <Separator orientation="vertical" className="h-4" />
            <span className="flex items-center gap-1">
              <Code2 className="w-3 h-3" />
              {files.length} files
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline">Next.js 15</Badge>
            <Badge variant="outline">TypeScript</Badge>
            <Badge variant="outline">Monaco Editor</Badge>
          </div>
        </div>
      </footer>

      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <LayoutTemplate className="w-5 h-5" />
              Code Templates
            </DialogTitle>
            <DialogDescription>Choose a template to quickly get started</DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[600px] p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map((template) => (
                <Card
                  key={template.id}
                  className="cursor-pointer hover:border-primary transition-colors"
                  onClick={() => handleApplyTemplate(template.id)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-base">{template.name}</CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="secondary">{template.category}</Badge>
                          <Badge variant="outline">{template.language}</Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{template.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}
