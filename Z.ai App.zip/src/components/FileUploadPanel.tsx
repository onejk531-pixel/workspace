'use client'

import { useState, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Upload,
  FileText,
  Trash2,
  Check,
  AlertCircle,
  X
} from 'lucide-react'
import { toast } from 'sonner'

interface UploadedFile {
  id: string
  name: string
  content: string
  size: number
  type: string
  language: string
}

interface FileUploadPanelProps {
  onFilesUploaded?: (files: UploadedFile[]) => void
}

export default function FileUploadPanel({ onFilesUploaded }: FileUploadPanelProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    const newFiles: UploadedFile[] = []

    Array.from(files).forEach((file) => {
      const reader = new FileReader()

      reader.onload = (e) => {
        const content = e.target?.result as string

        // Determine language from extension
        const ext = file.name.split('.').pop()?.toLowerCase()
        let language = 'text'

        switch (ext) {
          case 'js':
            language = 'javascript'
            break
          case 'ts':
            language = 'typescript'
            break
          case 'jsx':
            language = 'javascript'
            break
          case 'tsx':
            language = 'typescript'
            break
          case 'py':
            language = 'python'
            break
          case 'html':
            language = 'html'
            break
          case 'css':
            language = 'css'
            break
          case 'json':
            language = 'json'
            break
          case 'md':
            language = 'markdown'
            break
        }

        const newFile: UploadedFile = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          name: file.name,
          content,
          size: file.size,
          type: file.type,
          language
        }

        newFiles.push(newFile)
      }

      reader.readAsText(file)
    })

    // Wait for all files to be read
    setTimeout(() => {
      setUploadedFiles(prev => [...prev, ...newFiles])
      toast.success(`${newFiles.length} file${newFiles.length > 1 ? 's' : ''} uploaded!`)

      if (onFilesUploaded) {
        onFilesUploaded(newFiles)
      }
    }, 100)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    const files = e.dataTransfer.files
    if (!files || files.length === 0) return

    const newFiles: UploadedFile[] = []

    Array.from(files).forEach((file) => {
      const reader = new FileReader()

      reader.onload = (e) => {
        const content = e.target?.result as string

        // Determine language
        const ext = file.name.split('.').pop()?.toLowerCase()
        let language = 'text'

        switch (ext) {
          case 'js':
            language = 'javascript'
            break
          case 'ts':
            language = 'typescript'
            break
          case 'jsx':
            language = 'javascript'
            break
          case 'tsx':
            language = 'typescript'
            break
          case 'py':
            language = 'python'
            break
          case 'html':
            language = 'html'
            break
          case 'css':
            language = 'css'
            break
          case 'json':
            language = 'json'
            break
          case 'md':
            language = 'markdown'
            break
        }

        const newFile: UploadedFile = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          name: file.name,
          content,
          size: file.size,
          type: file.type,
          language
        }

        newFiles.push(newFile)
      }

      reader.readAsText(file)
    })

    setTimeout(() => {
      setUploadedFiles(prev => [...prev, ...newFiles])
      toast.success(`${newFiles.length} file${newFiles.length > 1 ? 's' : ''} uploaded!`)

      if (onFilesUploaded) {
        onFilesUploaded(newFiles)
      }
    }, 100)
  }

  const handleRemoveFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId))
    toast.success('File removed!')
  }

  const handleClearAll = () => {
    if (uploadedFiles.length === 0) return

    if (confirm('Clear all uploaded files?')) {
      setUploadedFiles([])
      toast.success('All files cleared!')
    }
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    const r = Math.round(bytes / Math.pow(k, i) * 100) / 100
    return `${r} ${sizes[i]}`
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="w-5 h-5" />
          File Upload
        </CardTitle>
        <CardDescription>
          Upload code files to your project or analyze them
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Upload Area */}
          <div
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".js,.ts,.jsx,.tsx,.py,.html,.css,.json,.md,.txt"
              onChange={handleFileSelect}
              className="hidden"
            />
            <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">
              Drop files here or click to browse
            </h3>
            <p className="text-sm text-muted-foreground">
              Supported: JS, TS, JSX, TSX, Python, HTML, CSS, JSON, MD
            </p>
          </div>

          {/* Uploaded Files List */}
          {uploadedFiles.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold">Uploaded Files ({uploadedFiles.length})</h4>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleClearAll}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear All
                </Button>
              </div>
              <ScrollArea className="h-64 border rounded-lg">
                {uploadedFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-3 border-b hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{file.name}</p>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">{file.language}</Badge>
                          <span className="text-xs text-muted-foreground">
                            {formatFileSize(file.size)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleRemoveFile(file.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </ScrollArea>
            </div>
          )}

          {uploadedFiles.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No files uploaded yet</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
