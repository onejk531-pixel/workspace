import { createServer } from 'http'
import { Server as SocketIOServer } from 'socket.io'
import ZAI from 'z-ai-web-dev-sdk'

const PORT = 3003

const httpServer = createServer()
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
})

// Store ZAI instance
let zaiInstance: any = null

async function getZAIInstance() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

// AI functions
async function* generateCodeStream(prompt: string, language: string) {
  const zai = await getZAIInstance()

  const systemPrompt = `You are an expert ${language} programmer. Write clean, efficient, and well-commented code.
Follow best practices and modern conventions.
IMPORTANT: Respond with the code first, wrapped in \`\`\`${language} and \`\`\`, then provide a brief explanation.`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: `Write ${language} code to: ${prompt}` }
      ],
      thinking: { type: 'disabled' },
      stream: true
    })

    for await (const chunk of completion) {
      const content = chunk.choices[0]?.delta?.content
      if (content) {
        yield content
      }
    }
  } catch (error) {
    console.error('Error in generateCodeStream:', error)
    throw error
  }
}

async function* debugCodeStream(code: string, issue: string, language: string) {
  const zai = await getZAIInstance()

  const systemPrompt = `You are an expert debugger for ${language}. Identify bugs and suggest fixes.
Provide the corrected code and explain what was wrong and how you fixed it.
IMPORTANT: Respond with the corrected code first, wrapped in \`\`\`${language} and \`\`\`, then provide the explanation.`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: `Code:\n${code}\n\nIssue: ${issue}\n\nFind the bug and provide the corrected code.` }
      ],
      thinking: { type: 'disabled' },
      stream: true
    })

    for await (const chunk of completion) {
      const content = chunk.choices[0]?.delta?.content
      if (content) {
        yield content
      }
    }
  } catch (error) {
    console.error('Error in debugCodeStream:', error)
    throw error
  }
}

async function* explainCodeStream(code: string, language: string) {
  const zai = await getZAIInstance()

  const systemPrompt = `You are a programming teacher. Explain code clearly and simply.
Break down what each part does and how they work together.
Use clear examples when appropriate.`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: `Explain what this ${language} code does:\n\n${code}` }
      ],
      thinking: { type: 'disabled' },
      stream: true
    })

    for await (const chunk of completion) {
      const content = chunk.choices[0]?.delta?.content
      if (content) {
        yield content
      }
    }
  } catch (error) {
    console.error('Error in explainCodeStream:', error)
    throw error
  }
}

async function* optimizeCodeStream(code: string, language: string) {
  const zai = await getZAIInstance()

  const systemPrompt = `You are a code optimization expert. Improve code performance, readability, and maintainability.
Suggest best practices and modern patterns.
IMPORTANT: Respond with the optimized code first, wrapped in \`\`\`${language} and \`\`\`, then explain the improvements.`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: `Optimize this ${language} code:\n\n${code}` }
      ],
      thinking: { type: 'disabled' },
      stream: true
    })

    for await (const chunk of completion) {
      const content = chunk.choices[0]?.delta?.content
      if (content) {
        yield content
      }
    }
  } catch (error) {
    console.error('Error in optimizeCodeStream:', error)
    throw error
  }
}

async function* generateTestsStream(code: string, language: string) {
  const zai = await getZAIInstance()

  const systemPrompt = `You are a testing expert. Generate comprehensive unit tests for the provided code.
Cover edge cases, happy path, and error scenarios.
IMPORTANT: Respond with the test code first, wrapped in \`\`\`${language} and \`\`\`, then explain the test coverage.`

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: `Generate comprehensive tests for this ${language} code:\n\n${code}` }
      ],
      thinking: { type: 'disabled' },
      stream: true
    })

    for await (const chunk of completion) {
      const content = chunk.choices[0]?.delta?.content
      if (content) {
        yield content
      }
    }
  } catch (error) {
    console.error('Error in generateTestsStream:', error)
    throw error
  }
}

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`)

  // Handle AI requests
  socket.on('ai:request', async (data) => {
    const { requestId, mode, message, code, language } = data

    console.log(`AI request [${requestId}]: mode=${mode}`)

    try {
      let streamGenerator: AsyncGenerator<string>

      switch (mode) {
        case 'generate':
          streamGenerator = generateCodeStream(message, language)
          break
        case 'debug':
          streamGenerator = debugCodeStream(code || message, message, language)
          break
        case 'explain':
          streamGenerator = explainCodeStream(code || '', language)
          break
        case 'optimize':
          streamGenerator = optimizeCodeStream(code || '', language)
          break
        case 'test':
          streamGenerator = generateTestsStream(code || '', language)
          break
        default:
          socket.emit('ai:error', { requestId, error: 'Unknown mode' })
          return
      }

      // Stream responses
      for await (const chunk of streamGenerator) {
        socket.emit('ai:chunk', { requestId, chunk })
      }

      // Signal completion
      socket.emit('ai:complete', { requestId })
    } catch (error) {
      console.error('Error processing AI request:', error)
      socket.emit('ai:error', {
        requestId,
        error: error instanceof Error ? error.message : 'Unknown error'
      })
    }
  })

  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`)
  })
})

// Start server
httpServer.listen(PORT, () => {
  console.log(`🚀 AI Streaming Service running on port ${PORT}`)
})
