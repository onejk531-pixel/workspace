import { createServer } from 'http'
import { Server as SocketIOServer } from 'socket.io'
import ZAI from 'z-ai-web-dev-sdk'
import { v4 as uuidv4 } from 'uuid'

const PORT = 3005

const httpServer = createServer()
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
})

// Store active sessions
const activeSessions = new Map<string, any>()

// AI Model Configuration
const AI_MODELS = {
  'glm-v': {
    name: 'GLM-V',
    description: 'General Language Model for versatile tasks',
    systemPrompt: 'You are an expert web developer specialized in creating modern, responsive web applications.'
  },
  'glm-4.5': {
    name: 'GLM-4.5',
    description: 'Advanced model for complex web development',
    systemPrompt: 'You are a senior web architect specializing in full-stack development and modern frameworks.'
  },
  'kaleido': {
    name: 'Kaleido',
    description: 'Multimodal model for visual and code generation',
    systemPrompt: 'You are a creative web designer and developer, focused on beautiful UI/UX and clean code.'
  }
}

// Get ZAI instance
let zaiInstance: any = null
async function getZAIInstance() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

// Generate web file using specified model
async function* generateWebFileStream(
  prompt: string,
  model: string = 'glm-v',
  context?: string
) {
  const zai = await getZAIInstance()
  const modelConfig = AI_MODELS[model as keyof typeof AI_MODELS] || AI_MODELS['glm-v']

  const systemPrompt = `${modelConfig.systemPrompt}

Create complete, production-ready web files (HTML, CSS, JavaScript, etc.) based on the user's requirements.
IMPORTANT: Always provide the file content wrapped in proper code blocks with language markers.
Format your response to clearly separate multiple files if needed.

When generating web files:
1. Always include DOCTYPE and proper HTML structure
2. Use modern CSS with responsive design
3. Include proper meta tags and accessibility attributes
4. Write clean, well-commented code
5. Ensure all interactive elements work
6. Use semantic HTML elements
7. Follow best practices for performance and SEO
`

  const messages: any[] = [
    { role: 'assistant', content: systemPrompt }
  ]

  // Add context if provided
  if (context) {
    messages.push(
      { role: 'user', content: `Context: ${context}` },
      { role: 'assistant', content: 'Understood. I will use this context for the file generation.' }
    )
  }

  messages.push({ role: 'user', content: prompt })

  try {
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: 'disabled' },
      stream: true
    })

    for await (const chunk of completion) {
      const content = chunk.choices[0]?.delta?.content
      if (content) {
        yield content
      }
    }
  } catch (error) {
    console.error('Error in generateWebFileStream:', error)
    throw error
  }
}

// Parse files from AI response
function parseFiles(content: string): Array<{ filename: string; content: string }> {
  const files: Array<{ filename: string; content: string }> = []
  const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g
  let match

  while ((match = codeBlockRegex.exec(content)) !== null) {
    const language = match[1] || 'txt'
    const fileContent = match[2]

    // Determine filename based on language
    let filename = 'index'
    switch (language) {
      case 'html':
        filename = 'index.html'
        break
      case 'css':
        filename = 'style.css'
        break
      case 'javascript':
      case 'js':
        filename = 'script.js'
        break
      case 'typescript':
      case 'ts':
        filename = 'script.ts'
        break
      default:
        filename = `file.${language}`
    }

    files.push({ filename, content: fileContent })
  }

  return files
}

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`Web Builder client connected: ${socket.id}`)
  const sessionId = uuidv4()
  socket.join(sessionId)

  // Send session ID to client
  socket.emit('web-builder:session', { sessionId, models: AI_MODELS })

  // Handle web file generation request
  socket.on('web-builder:generate', async (data) => {
    const { prompt, model, context, conversationHistory = [] } = data
    console.log(`Web Builder request [${sessionId}]: model=${model}`)

    io.to(sessionId).emit('web-builder:status', {
      sessionId,
      status: 'generating',
      model: model || 'glm-v'
    })

    let fullContent = ''

    try {
      const streamGenerator = generateWebFileStream(
        prompt,
        model || 'glm-v',
        context
      )

      // Stream responses
      for await (const chunk of streamGenerator) {
        fullContent += chunk
        io.to(sessionId).emit('web-builder:chunk', {
          sessionId,
          chunk
        })
      }

      // Parse files from the complete response
      const files = parseFiles(fullContent)

      // Signal completion with parsed files
      io.to(sessionId).emit('web-builder:complete', {
        sessionId,
        content: fullContent,
        files,
        model: model || 'glm-v'
      })
    } catch (error) {
      console.error('Error processing web builder request:', error)
      io.to(sessionId).emit('web-builder:error', {
        sessionId,
        error: error instanceof Error ? error.message : 'Unknown error'
      })
    }
  })

  // Handle model selection
  socket.on('web-builder:select-model', (data) => {
    const { model } = data
    const modelConfig = AI_MODELS[model as keyof typeof AI_MODELS]
    
    if (modelConfig) {
      io.to(sessionId).emit('web-builder:model-selected', {
        sessionId,
        model,
        name: modelConfig.name,
        description: modelConfig.description
      })
    } else {
      io.to(sessionId).emit('web-builder:error', {
        sessionId,
        error: `Unknown model: ${model}`
      })
    }
  })

  // Handle request cancellation
  socket.on('web-builder:cancel', () => {
    activeSessions.delete(sessionId)
    io.to(sessionId).emit('web-builder:status', {
      sessionId,
      status: 'cancelled'
    })
  })

  socket.on('disconnect', () => {
    console.log(`Web Builder client disconnected: ${socket.id}`)
    activeSessions.delete(sessionId)
  })
})

// Start server
httpServer.listen(PORT, () => {
  console.log(`🚀 Web Builder Service running on port ${PORT}`)
  console.log(`🤖 Available models: ${Object.keys(AI_MODELS).join(', ')}`)
  console.log(`📚 Model repositories:`)
  console.log(`   - GLM-V: https://github.com/zai-org/GLM-V`)
  console.log(`   - GLM-4.5: https://github.com/zai-org/GLM-4.5`)
  console.log(`   - Kaleido: https://github.com/zai-org/Kaleido`)
})
