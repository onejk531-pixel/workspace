import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

let zaiInstance: any = null

async function getZAIInstance() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

async function generateCode(prompt: string, language: string): Promise<{ code: string; explanation: string }> {
  const zai = await getZAIInstance()

  const systemPrompt = `You are an expert ${language} programmer. Write clean, efficient, and well-commented code.
Follow best practices and modern conventions.
IMPORTANT: Respond with the code first, wrapped in \`\`\`${language} and \`\`\`, then provide a brief explanation.`

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'assistant',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Write ${language} code to: ${prompt}`
      }
    ],
    thinking: { type: 'disabled' }
  })

  const response = completion.choices[0]?.message?.content || ''

  // Extract code from markdown code blocks
  const codeMatch = response.match(/```(\w+)?\n([\s\S]*?)```/)
  const code = codeMatch ? codeMatch[2] : response
  const explanation = codeMatch
    ? response.replace(/```[\s\S]*?```/, '').trim()
    : 'Code generated based on your request.'

  return { code, explanation }
}

async function debugCode(code: string, issue: string, language: string): Promise<{ code: string; explanation: string }> {
  const zai = await getZAIInstance()

  const systemPrompt = `You are an expert debugger for ${language}. Identify bugs and suggest fixes.
Provide the corrected code and explain what was wrong and how you fixed it.
IMPORTANT: Respond with the corrected code first, wrapped in \`\`\`${language} and \`\`\`, then provide the explanation.`

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'assistant',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Code:\n${code}\n\nIssue: ${issue}\n\nFind the bug and provide the corrected code.`
      }
    ],
    thinking: { type: 'disabled' }
  })

  const response = completion.choices[0]?.message?.content || ''

  // Extract code from markdown code blocks
  const codeMatch = response.match(/```(\w+)?\n([\s\S]*?)```/)
  const correctedCode = codeMatch ? codeMatch[2] : code
  const explanation = codeMatch
    ? response.replace(/```[\s\S]*?```/, '').trim()
    : response

  return { code: correctedCode, explanation }
}

async function explainCode(code: string, language: string): Promise<{ explanation: string }> {
  const zai = await getZAIInstance()

  const systemPrompt = `You are a programming teacher. Explain code clearly and simply.
Break down what each part does and how they work together.
Use clear examples when appropriate.`

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'assistant',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Explain what this ${language} code does:\n\n${code}`
      }
    ],
    thinking: { type: 'disabled' }
  })

  const explanation = completion.choices[0]?.message?.content || ''

  return { explanation }
}

async function optimizeCode(code: string, language: string): Promise<{ code: string; explanation: string }> {
  const zai = await getZAIInstance()

  const systemPrompt = `You are a code optimization expert. Improve code performance, readability, and maintainability.
Suggest best practices and modern patterns.
IMPORTANT: Respond with the optimized code first, wrapped in \`\`\`${language} and \`\`\`, then explain the improvements.`

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'assistant',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Optimize this ${language} code:\n\n${code}`
      }
    ],
    thinking: { type: 'disabled' }
  })

  const response = completion.choices[0]?.message?.content || ''

  // Extract code from markdown code blocks
  const codeMatch = response.match(/```(\w+)?\n([\s\S]*?)```/)
  const optimizedCode = codeMatch ? codeMatch[2] : code
  const explanation = codeMatch
    ? response.replace(/```[\s\S]*?```/, '').trim()
    : response

  return { code: optimizedCode, explanation }
}

async function generateTests(code: string, language: string): Promise<{ code: string; explanation: string }> {
  const zai = await getZAIInstance()

  const systemPrompt = `You are a testing expert. Generate comprehensive unit tests for the provided code.
Cover edge cases, happy path, and error scenarios.
IMPORTANT: Respond with the test code first, wrapped in \`\`\`${language} and \`\`\`, then explain the test coverage.`

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'assistant',
        content: systemPrompt
      },
      {
        role: 'user',
        content: `Generate comprehensive tests for this ${language} code:\n\n${code}`
      }
    ],
    thinking: { type: 'disabled' }
  })

  const response = completion.choices[0]?.message?.content || ''

  // Extract code from markdown code blocks
  const codeMatch = response.match(/```(\w+)?\n([\s\S]*?)```/)
  const testCode = codeMatch ? codeMatch[2] : response
  const explanation = codeMatch
    ? response.replace(/```[\s\S]*?```/, '').trim()
    : 'Tests generated for your code.'

  return { code: testCode, explanation }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, mode, code, language, conversationHistory = [] } = body

    if (!message) {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      )
    }

    // Build messages array with conversation history
    const messages: Array<{ role: string; content: string }> = []

    // Add conversation history if provided
    if (conversationHistory && conversationHistory.length > 0) {
      messages.push(...conversationHistory)
    }

    let systemPrompt = ''
    let userPrompt = ''

    // Set up prompts based on mode
    switch (mode) {
      case 'generate':
        systemPrompt = `You are an expert ${language} programmer. Write clean, efficient, and well-commented code.
Follow best practices and modern conventions.
IMPORTANT: Respond with the code first, wrapped in \`\`\`${language} and \`\`\`, then provide a brief explanation.`
        userPrompt = `Write ${language} code to: ${message}`
        break

      case 'debug':
        systemPrompt = `You are an expert debugger for ${language}. Identify bugs and suggest fixes.
Provide the corrected code and explain what was wrong and how you fixed it.
IMPORTANT: Respond with the corrected code first, wrapped in \`\`\`${language} and \`\`\`, then provide the explanation.`
        userPrompt = `Code:\n${code || message}\n\nIssue: ${message}\n\nFind the bug and provide the corrected code.`
        break

      case 'explain':
        systemPrompt = `You are a programming teacher. Explain code clearly and simply.
Break down what each part does and how they work together.
Use clear examples when appropriate.`
        userPrompt = `Explain what this ${language} code does:\n\n${code || message}`
        break

      case 'optimize':
        systemPrompt = `You are a code optimization expert. Improve code performance, readability, and maintainability.
Suggest best practices and modern patterns.
IMPORTANT: Respond with the optimized code first, wrapped in \`\`\`${language} and \`\`\`, then explain the improvements.`
        userPrompt = `Optimize this ${language} code:\n\n${code || message}`
        break

      case 'test':
        systemPrompt = `You are a testing expert. Generate comprehensive unit tests for the provided code.
Cover edge cases, happy path, and error scenarios.
IMPORTANT: Respond with the test code first, wrapped in \`\`\`${language} and \`\`\`, then explain the test coverage.`
        userPrompt = `Generate comprehensive tests for this ${language} code:\n\n${code || message}`
        break

      default:
        systemPrompt = 'You are a helpful coding assistant. Help users with code generation, debugging, and explanations. Be concise and practical.'
        userPrompt = message
    }

    const zai = await getZAIInstance()

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        ...messages,
        { role: 'user', content: userPrompt }
      ],
      thinking: { type: 'disabled' }
    })

    const response = completion.choices[0]?.message?.content || ''

    let generatedCode: string | undefined

    // Extract code from markdown code blocks for relevant modes
    if (['generate', 'debug', 'optimize', 'test'].includes(mode)) {
      const codeMatch = response.match(/```(\w+)?\n([\s\S]*?)```/)
      generatedCode = codeMatch ? codeMatch[2] : undefined
    }

    return NextResponse.json({
      success: true,
      response,
      code: generatedCode
    })
  } catch (error) {
    console.error('AI Assistant Error:', error)
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to process request',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
