// Code execution worker
self.onmessage = async (e) => {
  const { code, language, taskId } = e.data

  try {
    const startTime = performance.now()
    let output = ''
    let exitCode = 0

    switch (language) {
      case 'typescript':
      case 'javascript':
        try {
          const result = eval(code)
          output = String(result)
        } catch (error) {
          output = `Error: ${error.message}`
          exitCode = 1
        }
        break

      case 'python':
        output = `Python execution: ${code.substring(0, 100)}...`
        break

      case 'shell':
        output = `Shell command: ${code.substring(0, 100)}...`
        break

      default:
        output = `Language ${language} not supported in worker`
        exitCode = 1
    }

    const executionTime = performance.now() - startTime
    const chunks = output.match(/.{1,100}/g) || [output]

    for (let i = 0; i < chunks.length; i++) {
      self.postMessage({
        type: 'chunk',
        taskId,
        chunk: chunks[i],
        progress: Math.round(((i + 1) / chunks.length) * 100)
      })
      await new Promise(resolve => setTimeout(resolve, 50))
    }

    self.postMessage({
      type: 'complete',
      taskId,
      output,
      exitCode,
      executionTime
    })

  } catch (error) {
    self.postMessage({
      type: 'error',
      taskId,
      error: error instanceof Error ? error.message : String(error)
    })
  }
})
