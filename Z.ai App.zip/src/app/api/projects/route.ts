import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all projects
export async function GET() {
  try {
    const projects = await db.project.findMany({
      include: {
        files: {
          orderBy: {
            order: 'asc'
          }
        },
        templates: true
      },
      orderBy: {
        updatedAt: 'desc'
      }
    })

    return NextResponse.json({ success: true, projects })
  } catch (error) {
    console.error('Error fetching projects:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch projects' },
      { status: 500 }
    )
  }
}

// POST create new project
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, files = [] } = body

    if (!name) {
      return NextResponse.json(
        { success: false, error: 'Project name is required' },
        { status: 400 }
      )
    }

    const project = await db.project.create({
      data: {
        name,
        description,
        files: {
          create: files.map((file: any, index: number) => ({
            name: file.name,
            language: file.language,
            content: file.content,
            order: index
          }))
        }
      },
      include: {
        files: {
          orderBy: {
            order: 'asc'
          }
        }
      }
    })

    return NextResponse.json({ success: true, project })
  } catch (error) {
    console.error('Error creating project:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create project' },
      { status: 500 }
    )
  }
}
