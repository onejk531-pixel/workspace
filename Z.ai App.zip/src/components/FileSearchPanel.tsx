'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Search,
  FileText,
  Filter,
  ArrowUpDown,
  X,
  ExternalLink
} from 'lucide-react'
import { toast } from 'sonner'

interface FileSearchPanelProps {
  files?: Array<{ id: string; name: string; language: string; content: string }>
  onFileSelect?: (fileId: string) => void
  onContentSearch?: (query: string) => void
}

export default function FileSearchPanel({ files = [], onFileSelect, onContentSearch }: FileSearchPanelProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [searchType, setSearchType] = useState<'name' | 'content' | 'both'>('name')
  const [fileTypeFilter, setFileTypeFilter] = useState<string>('all')
  const [results, setResults] = useState<Array<{
    file: any
    matches: Array<{ line: number; content: string; context: string }>
  }>>([])
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      toast.error('Please enter a search query')
      return
    }

    setIsSearching(true)
    setResults([])

    const query = searchQuery.toLowerCase()

    if (searchType === 'name') {
      // Search by filename only
      const matchedFiles = files.filter(file =>
        file.name.toLowerCase().includes(query)
      )

      setResults(matchedFiles.map(file => ({
        file,
        matches: []
      })))

      toast.success(`Found ${matchedFiles.length} file${matchedFiles.length !== 1 ? 's' : ''} by name`)
    } else if (searchType === 'content') {
      // Search by content
      const fileResults = files.map(file => {
        const lines = file.content.split('\n')
        const matches: Array<{ line: number; content: string; context: string }> = []

        lines.forEach((line, index) => {
          if (line.toLowerCase().includes(query)) {
            // Get context (2 lines before and after)
            const startLine = Math.max(0, index - 2)
            const endLine = Math.min(lines.length - 1, index + 2)
            const contextLines = lines.slice(startLine, endLine + 1)
            const context = contextLines.join('\n')

            matches.push({
              line: index + 1,
              content: line,
              context
            })
          }
        })

        return { file, matches }
      }).filter(result => result.matches.length > 0)

      setResults(fileResults)

      const totalMatches = fileResults.reduce((sum, result) => sum + result.matches.length, 0)
      toast.success(`Found ${totalMatches} match${totalMatches !== 1 ? 'es' : ''} in ${fileResults.length} file${fileResults.length !== 1 ? 's' : ''}`)
    } else {
      // Search both
      const fileResults = files.map(file => {
        // Name match
        const nameMatch = file.name.toLowerCase().includes(query)

        // Content matches
        const lines = file.content.split('\n')
        const contentMatches: Array<{ line: number; content: string; context: string }> = []

        lines.forEach((line, index) => {
          if (line.toLowerCase().includes(query)) {
            const startLine = Math.max(0, index - 2)
            const endLine = Math.min(lines.length - 1, index + 2)
            const contextLines = lines.slice(startLine, endLine + 1)
            const context = contextLines.join('\n')

            contentMatches.push({
              line: index + 1,
              content: line,
              context
            })
          }
        })

        return {
          file,
          matches: nameMatch ? [] : contentMatches
        }
      }).filter(result => result.matches.length > 0 || file.name.toLowerCase().includes(query))

      setResults(fileResults)

      const totalMatches = fileResults.reduce((sum, result) => {
        return sum + (result.file.name.toLowerCase().includes(query) ? 1 : result.matches.length)
      }, 0)
      toast.success(`Found ${totalMatches} match${totalMatches !== 1 ? 'es' : ''} in ${fileResults.length} file${fileResults.length !== 1 ? 's' : ''}`)
    }

    setTimeout(() => setIsSearching(false), 100)
  }

  const handleClear = () => {
    setSearchQuery('')
    setResults([])
    toast.success('Search cleared!')
  }

  const handleResultClick = (fileId: string) => {
    if (onFileSelect) {
      onFileSelect(fileId)
    }
  }

  const handleContentSearch = () => {
    if (onContentSearch && searchQuery.trim()) {
      onContentSearch(searchQuery)
    }
  }

  const highlightMatch = (text: string, query: string) => {
    if (!query) return text
    const regex = new RegExp(`(${query})`, 'gi')
    return text.replace(regex, '<mark class="bg-yellow-200 dark:bg-yellow-800">$1</mark>')
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5" />
          File Search
        </CardTitle>
        <CardDescription>
          Search files by name or content with filters
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Search Controls */}
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Search Type</Label>
                <Select value={searchType} onValueChange={(v: any) => setSearchType(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">By Filename</SelectItem>
                    <SelectItem value="content">By Content</SelectItem>
                    <SelectItem value="both">Both</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>File Type</Label>
                <Select value={fileTypeFilter} onValueChange={setFileTypeFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Files</SelectItem>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="typescript">TypeScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="html">HTML</SelectItem>
                    <SelectItem value="css">CSS</SelectItem>
                    <SelectItem value="json">JSON</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2">
              <Input
                placeholder="Enter search query..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleSearch()
                  }
                }}
                className="flex-1"
              />
              <Button onClick={handleSearch} disabled={isSearching}>
                <Search className="w-4 h-4 mr-2" />
                Search
              </Button>
              {searchQuery && (
                <Button variant="outline" onClick={handleClear}>
                  <X className="w-4 h-4 mr-2" />
                  Clear
                </Button>
              )}
            </div>

            {/* Sort Options */}
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => toast.info('Sort options coming soon!')}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => toast.info('Sort options coming soon!')}
              >
                <ArrowUpDown className="w-4 h-4 mr-2" />
                Sort
              </Button>
            </div>
          </div>

          <Separator />

          {/* Search Results */}
          <div className="space-y-2">
            {isSearching ? (
              <div className="text-center py-8 text-muted-foreground">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-3"></div>
                <p className="text-sm">Searching...</p>
              </div>
            ) : results.length > 0 ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold">
                    Results ({results.length} file{results.length !== 1 ? 's' : ''})
                  </h4>
                  {searchType === 'content' && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleContentSearch}
                    >
                      <Search className="w-4 h-4 mr-2" />
                      Search in AI
                    </Button>
                  )}
                </div>

                <ScrollArea className="h-96 border rounded-lg">
                  {results.map((result, index) => (
                    <div
                      key={result.file.id}
                      onClick={() => handleResultClick(result.file.id)}
                      className="p-3 border-b hover:bg-muted/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <FileText className="w-4 h-4 text-muted-foreground" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{result.file.name}</p>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary">{result.file.language}</Badge>
                            {result.matches.length > 0 && (
                              <Badge variant="outline">
                                {result.matches.length} match{result.matches.length !== 1 ? 'es' : ''}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Content matches with context */}
                      {result.matches.length > 0 && (
                        <div className="space-y-2">
                          {result.matches.slice(0, 5).map((match, matchIndex) => (
                            <div key={matchIndex} className="text-xs bg-muted p-2 rounded">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-muted-foreground">
                                  Line {match.line}
                                </span>
                                <Badge variant="outline">Match</Badge>
                              </div>
                              <pre
                                className="whitespace-pre-wrap break-words"
                                dangerouslySetInnerHTML={{
                                  __html: highlightMatch(match.context, searchQuery)
                                }}
                              />
                            </div>
                          ))}
                          {result.matches.length > 5 && (
                            <p className="text-xs text-muted-foreground text-center">
                              +{result.matches.length - 5} more match{result.matches.length - 5 !== 1 ? 'es' : ''}...
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </ScrollArea>
              </div>
            ) : !isSearching && (
              <div className="text-center py-8 text-muted-foreground">
                <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p className="text-sm">
                  {searchQuery ? 'No results found. Try a different query.' : 'Enter a search query above'}
                </p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
