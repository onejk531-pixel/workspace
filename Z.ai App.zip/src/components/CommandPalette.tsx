'use client'

import { useState, useEffect, useRef } from 'react'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Search, Save, FolderPlus, Terminal, Zap, Upload, Search as SearchIcon, Settings, Sparkles, LayoutTemplate, Layers, FileText, Play, Download, X } from 'lucide-react'
import { toast } from 'sonner'
import { useKeyboardShortcuts } from '@/hooks/useKeyboardShortcuts'

interface Command {
  id: string
  label: string
  shortcut?: string
  icon: React.ReactNode
  action: () => void
  category?: string
}

interface CommandPaletteProps {
  onSave?: () => void
  onNewFile?: () => void
  onNewProject?: () => void
  onOpenTerminal?: () => void
  onOpenWebBuilder?: () => void
  onOpenFileUpload?: () => void
  onOpenFileSearch?: () => void
  onOpenSettings?: () => void
  onOpenTemplates?: () => void
  onFormatCode?: () => void
  onRunCode?: () => void
  onDownloadFile?: () => void
  onCopyCode?: () => void
  onCreateProject?: () => void
}

export default function CommandPalette({
  onSave,
  onNewFile,
  onNewProject,
  onOpenTerminal,
  onOpenWebBuilder,
  onOpenFileUpload,
  onOpenFileSearch,
  onOpenSettings,
  onOpenTemplates,
  onFormatCode,
  onRunCode,
  onDownloadFile,
  onCopyCode,
  onCreateProject
}: CommandPaletteProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  const commands: Command[] = [
    // File operations
    {
      id: 'save',
      label: 'Save Project',
      shortcut: 'Ctrl+S',
      icon: <Save className="w-4 h-4" />,
      action: () => {
        onSave?.()
        setIsOpen(false)
      },
      category: 'File'
    },
    {
      id: 'new-file',
      label: 'New File',
      shortcut: 'Ctrl+N',
      icon: <FileText className="w-4 h-4" />,
      action: () => {
        onNewFile?.()
        setIsOpen(false)
      },
      category: 'File'
    },
    {
      id: 'new-project',
      label: 'Create New Project',
      shortcut: 'Ctrl+Shift+N',
      icon: <FolderPlus className="w-4 h-4" />,
      action: () => {
        onCreateProject?.()
        setIsOpen(false)
      },
      category: 'File'
    },
    {
      id: 'copy-code',
      label: 'Copy Code',
      shortcut: 'Ctrl+C',
      icon: <Copy className="w-4 h-4" />,
      action: () => {
        onCopyCode?.()
        setIsOpen(false)
      },
      category: 'File'
    },
    {
      id: 'download-file',
      label: 'Download File',
      shortcut: 'Ctrl+D',
      icon: <Download className="w-4 h-4" />,
      action: () => {
        onDownloadFile?.()
        setIsOpen(false)
      },
      category: 'File'
    },

    // Edit operations
    {
      id: 'format-code',
      label: 'Format Code',
      shortcut: 'Shift+Alt+F',
      icon: <Sparkles className="w-4 h-4" />,
      action: () => {
        onFormatCode?.()
        setIsOpen(false)
      },
      category: 'Edit'
    },

    // View operations
    {
      id: 'terminal',
      label: 'Open Terminal',
      shortcut: 'Ctrl+B',
      icon: <Terminal className="w-4 h-4" />,
      action: () => {
        onOpenTerminal?.()
        setIsOpen(false)
      },
      category: 'View'
    },
    {
      id: 'web-builder',
      label: 'Open Web Builder',
      shortcut: 'Ctrl+Shift+B',
      icon: <Zap className="w-4 h-4" />,
      action: () => {
        onOpenWebBuilder?.()
        setIsOpen(false)
      },
      category: 'View'
    },
    {
      id: 'file-upload',
      label: 'Upload File',
      shortcut: 'Ctrl+U',
      icon: <Upload className="w-4 h-4" />,
      action: () => {
        onOpenFileUpload?.()
        setIsOpen(false)
      },
      category: 'View'
    },
    {
      id: 'file-search',
      label: 'Search Files',
      shortcut: 'Ctrl+Shift+F',
      icon: <SearchIcon className="w-4 h-4" />,
      action: () => {
        onOpenFileSearch?.()
        setIsOpen(false)
      },
      category: 'View'
    },
    {
      id: 'settings',
      label: 'Open Settings',
      shortcut: 'Ctrl+,',
      icon: <Settings className="w-4 h-4" />,
      action: () => {
        onOpenSettings?.()
        setIsOpen(false)
      },
      category: 'View'
    },

    // Tools operations
    {
      id: 'run-code',
      label: 'Run Code',
      shortcut: 'F5',
      icon: <Play className="w-4 h-4" />,
      action: () => {
        onRunCode?.()
        setIsOpen(false)
      },
      category: 'Tools'
    },

    // Project operations
    {
      id: 'templates',
      label: 'Open Templates',
      shortcut: 'Ctrl+T',
      icon: <LayoutTemplate className="w-4 h-4" />,
      action: () => {
        onOpenTemplates?.()
        setIsOpen(false)
      },
      category: 'Project'
    },
  ]

  useKeyboardShortcuts({
    'ctrl+shift+p': () => {
      setIsOpen(true)
      setTimeout(() => inputRef.current?.focus(), 100)
    },
    'escape': () => setIsOpen(false)
  })

  const handleCommand = (command: Command) => {
    command.action()
    setQuery('')
  }

  const filteredCommands = commands.filter(command => {
    const matchesQuery = command.label.toLowerCase().includes(query.toLowerCase()) ||
                           command.category?.toLowerCase().includes(query.toLowerCase())
    return matchesQuery
  })

  const categories = Array.from(new Set(filteredCommands.map(cmd => cmd.category).filter(Boolean)))

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden">
        <div className="flex flex-col h-[600px]">
          {/* Search Input */}
          <div className="flex items-center gap-3 p-4 border-b">
            <Search className="w-5 h-5 text-muted-foreground" />
            <Input
              ref={inputRef}
              placeholder="Search commands..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setIsOpen(false)
                }
              }}
            />
            <kbd className="text-xs bg-muted px-2 py-1 rounded">ESC</kbd>
          </div>

          {/* Commands List */}
          <div className="flex-1 overflow-auto">
            {query === '' ? (
              <div className="p-4 space-y-4">
                <div>
                  <h3 className="text-xs font-semibold text-muted-foreground mb-2">Recently Used</h3>
                  <div className="space-y-1">
                    {commands.slice(0, 4).map((command) => (
                      <button
                        key={command.id}
                        onClick={() => handleCommand(command)}
                        className="w-full flex items-center justify-between p-2 rounded hover:bg-accent transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          {command.icon}
                          <span className="text-sm">{command.label}</span>
                        </div>
                        <kbd className="text-xs bg-muted px-2 py-1 rounded">
                          {command.shortcut}
                        </kbd>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-muted-foreground mb-2">All Categories</h3>
                  <div className="grid grid-cols-3 gap-2">
                    {categories.map((category) => (
                      <button
                        key={category}
                        onClick={() => setQuery(category)}
                        className="p-2 text-sm border rounded hover:bg-accent transition-colors"
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 space-y-2">
                {categories.map((category) => (
                  <div key={category}>
                    <h3 className="text-xs font-semibold text-muted-foreground mb-2">
                      {category}
                    </h3>
                    {filteredCommands
                      .filter(cmd => cmd.category === category)
                      .map((command) => (
                        <button
                          key={command.id}
                          onClick={() => handleCommand(command)}
                          className="w-full flex items-center justify-between p-2 rounded hover:bg-accent transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            {command.icon}
                            <span className="text-sm">
                              {command.label.replace(
                                new RegExp(query, 'gi'),
                                match => `<mark class="bg-yellow-200 dark:bg-yellow-800">${match}</mark>`
                              )}
                            </span>
                          </div>
                          {command.shortcut && (
                            <kbd className="text-xs bg-muted px-2 py-1 rounded">
                              {command.shortcut}
                            </kbd>
                          )}
                        </button>
                      ))}
                  </div>
                ))}
                {filteredCommands.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">No commands found for "{query}"</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-3 border-t text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <span>Press</span>
              <kbd className="bg-muted px-1.5 py-0.5 rounded">Ctrl</kbd>
              <span>+</span>
              <kbd className="bg-muted px-1.5 py-0.5 rounded">Shift</kbd>
              <span>+</span>
              <kbd className="bg-muted px-1.5 py-0.5 rounded">P</kbd>
              <span>to open</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-1 hover:text-foreground transition-colors"
            >
              <X className="w-4 h-4" />
              <span>Close</span>
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
