import { db } from '../src/lib/db'

async function main() {
  console.log('🌱 Seeding templates...')

  // Create default templates
  const templates = [
    {
      name: 'Next.js API Route',
      description: 'Basic Next.js 15 API route with TypeScript',
      category: 'Next.js',
      language: 'typescript',
      content: `import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const param = searchParams.get('param')

    return NextResponse.json({
      success: true,
      message: 'Hello from API!',
      data: { param }
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Process your data here
    const result = { ...body, processed: true }

    return NextResponse.json({ success: true, data: result })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Invalid request' },
      { status: 400 }
    )
  }
}
`
    },
    {
      name: 'React Component',
      description: 'Functional React component with TypeScript',
      category: 'React',
      language: 'typescript',
      content: `'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

interface Props {
  title: string
  description?: string
  onAction?: () => void
}

export default function MyComponent({ title, description, onAction }: Props) {
  const [count, setCount] = useState(0)

  const handleClick = () => {
    setCount(c => c + 1)
    onAction?.()
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <p>Count: {count}</p>
        <Button onClick={handleClick}>Increment</Button>
      </CardContent>
    </Card>
  )
}
`
    },
    {
      name: 'Express Server',
      description: 'Basic Express.js server with TypeScript',
      category: 'Backend',
      language: 'typescript',
      content: `import express, { Request, Response } from 'express'
import cors from 'cors'

const app = express()
const PORT = process.env.PORT || 3001

app.use(cors())
app.use(express.json())

// Health check
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// Example API route
app.get('/api/data', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: [
      { id: 1, name: 'Item 1' },
      { id: 2, name: 'Item 2' },
      { id: 3, name: 'Item 3' }
    ]
  })
})

app.post('/api/data', (req: Request, res: Response) => {
  const { name } = req.body
  res.json({
    success: true,
    data: { id: Date.now(), name }
  })
})

app.listen(PORT, () => {
  console.log(\`🚀 Server running on port \${PORT}\`)
})
`
    },
    {
      name: 'Python FastAPI',
      description: 'FastAPI endpoint with Pydantic models',
      category: 'Backend',
      language: 'python',
      content: `from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="My API", version="1.0.0")

class Item(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    tax: Optional[float] = None

items_db = {}

@app.get("/")
async def root():
    return {"message": "Welcome to the API"}

@app.get("/items/{item_id}")
async def read_item(item_id: int):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail="Item not found")
    return items_db[item_id]

@app.post("/items/{item_id}")
async def create_item(item_id: int, item: Item):
    if item_id in items_db:
        raise HTTPException(status_code=400, detail="Item already exists")
    items_db[item_id] = item
    return {"message": "Item created", "item": item}

@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Item):
    if item_id not in items_db:
        raise HTTPException(status_code=404, detail="Item not found")
    items_db[item_id] = item
    return {"message": "Item updated", "item": item}
`
    },
    {
      name: 'React Hook',
      description: 'Custom React hook for data fetching',
      category: 'React',
      language: 'typescript',
      content: `import { useState, useEffect, useCallback } from 'react'

interface UseAsyncResult<T> {
  data: T | null
  loading: boolean
  error: string | null
  refetch: () => Promise<void>
}

export function useAsync<T>(
  asyncFunction: () => Promise<T>,
  immediate = true
): UseAsyncResult<T> {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const execute = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const result = await asyncFunction()
      setData(result)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }, [asyncFunction])

  useEffect(() => {
    if (immediate) {
      execute()
    }
  }, [execute, immediate])

  return { data, loading, error, refetch: execute }
}
`
    },
    {
      name: 'Prisma Schema',
      description: 'Prisma ORM schema example',
      category: 'Database',
      language: 'prisma',
      content: `// This is your Prisma schema file

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  posts     Post[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Post {
  id        String   @id @default(cuid())
  title     String
  content   String?
  published Boolean  @default(false)
  authorId  String
  author    User     @relation(fields: [authorId], references: [id])
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
`
    }
  ]

  for (const template of templates) {
    await db.template.create({
      data: template
    })
    console.log(`✅ Created template: ${template.name}`)
  }

  console.log('🎉 Seeding completed!')
}

main()
  .catch((e) => {
    console.error('❌ Error seeding:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
