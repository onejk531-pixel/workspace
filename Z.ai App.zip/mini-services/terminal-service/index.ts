import { createServer } from 'http'
import { Server as SocketIOServer } from 'socket.io'
import { spawn } from 'child_process'
import { v4 as uuidv4 } from 'uuid'

const PORT = 3004

const httpServer = createServer()
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
})

// Store active processes
const activeProcesses = new Map<string, any>()

// Execute Node.js code
async function executeNodeJS(code: string, sessionId: string) {
  return new Promise((resolve, reject) => {
    let output = ''
    let error = ''

    const process = spawn('node', ['-e', code], {
      cwd: '/tmp',
      timeout: 10000 // 10 second timeout
    })

    process.stdout.on('data', (data) => {
      output += data.toString()
      io.to(sessionId).emit('terminal:output', {
        sessionId,
        output: data.toString(),
        type: 'stdout'
      })
    })

    process.stderr.on('data', (data) => {
      error += data.toString()
      io.to(sessionId).emit('terminal:output', {
        sessionId,
        output: data.toString(),
        type: 'stderr'
      })
    })

    process.on('close', (code) => {
      activeProcesses.delete(sessionId)
      io.to(sessionId).emit('terminal:complete', {
        sessionId,
        exitCode: code,
        output,
        error
      })
      resolve({ exitCode: code, output, error })
    })

    process.on('error', (err) => {
      activeProcesses.delete(sessionId)
      io.to(sessionId).emit('terminal:error', {
        sessionId,
        error: err.message
      })
      reject(err)
    })

    // Store process for potential cancellation
    activeProcesses.set(sessionId, process)
  })
}

// Execute Python code
async function executePython(code: string, sessionId: string) {
  return new Promise((resolve, reject) => {
    let output = ''
    let error = ''

    const process = spawn('python3', ['-c', code], {
      cwd: '/tmp',
      timeout: 10000
    })

    process.stdout.on('data', (data) => {
      output += data.toString()
      io.to(sessionId).emit('terminal:output', {
        sessionId,
        output: data.toString(),
        type: 'stdout'
      })
    })

    process.stderr.on('data', (data) => {
      error += data.toString()
      io.to(sessionId).emit('terminal:output', {
        sessionId,
        output: data.toString(),
        type: 'stderr'
      })
    })

    process.on('close', (code) => {
      activeProcesses.delete(sessionId)
      io.to(sessionId).emit('terminal:complete', {
        sessionId,
        exitCode: code,
        output,
        error
      })
      resolve({ exitCode: code, output, error })
    })

    process.on('error', (err) => {
      activeProcesses.delete(sessionId)
      io.to(sessionId).emit('terminal:error', {
        sessionId,
        error: err.message
      })
      reject(err)
    })

    activeProcesses.set(sessionId, process)
  })
}

// Execute shell commands
async function executeShell(command: string, sessionId: string) {
  return new Promise((resolve, reject) => {
    let output = ''
    let error = ''

    const process = spawn('bash', ['-c', command], {
      cwd: '/tmp',
      timeout: 10000
    })

    process.stdout.on('data', (data) => {
      output += data.toString()
      io.to(sessionId).emit('terminal:output', {
        sessionId,
        output: data.toString(),
        type: 'stdout'
      })
    })

    process.stderr.on('data', (data) => {
      error += data.toString()
      io.to(sessionId).emit('terminal:output', {
        sessionId,
        output: data.toString(),
        type: 'stderr'
      })
    })

    process.on('close', (code) => {
      activeProcesses.delete(sessionId)
      io.to(sessionId).emit('terminal:complete', {
        sessionId,
        exitCode: code,
        output,
        error
      })
      resolve({ exitCode: code, output, error })
    })

    process.on('error', (err) => {
      activeProcesses.delete(sessionId)
      io.to(sessionId).emit('terminal:error', {
        sessionId,
        error: err.message
      })
      reject(err)
    })

    activeProcesses.set(sessionId, process)
  })
}

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`Terminal client connected: ${socket.id}`)
  const sessionId = uuidv4()
  socket.join(sessionId)

  // Send session ID to client
  socket.emit('terminal:session', { sessionId })

  // Handle code execution requests
  socket.on('terminal:execute', async (data) => {
    const { language, code } = data
    console.log(`Executing ${language} code for session ${sessionId}`)

    io.to(sessionId).emit('terminal:output', {
      sessionId,
      output: `> Executing ${language}...\n`,
      type: 'info'
    })

    try {
      switch (language) {
        case 'javascript':
        case 'typescript':
          await executeNodeJS(code, sessionId)
          break
        case 'python':
          await executePython(code, sessionId)
          break
        case 'shell':
          await executeShell(code, sessionId)
          break
        default:
          io.to(sessionId).emit('terminal:error', {
            sessionId,
            error: `Unsupported language: ${language}`
          })
      }
    } catch (error) {
      console.error(`Error executing ${language}:`, error)
    }
  })

  // Handle execution cancellation
  socket.on('terminal:cancel', () => {
    const process = activeProcesses.get(sessionId)
    if (process) {
      process.kill()
      activeProcesses.delete(sessionId)
      io.to(sessionId).emit('terminal:output', {
        sessionId,
        output: '\n> Execution cancelled\n',
        type: 'info'
      })
    }
  })

  // Handle terminal clear
  socket.on('terminal:clear', () => {
    io.to(sessionId).emit('terminal:cleared', { sessionId })
  })

  socket.on('disconnect', () => {
    console.log(`Terminal client disconnected: ${socket.id}`)
    // Cancel any running process
    const process = activeProcesses.get(sessionId)
    if (process) {
      process.kill()
      activeProcesses.delete(sessionId)
    }
  })
})

// Start server
httpServer.listen(PORT, () => {
  console.log(`🚀 Terminal Execution Service running on port ${PORT}`)
})
