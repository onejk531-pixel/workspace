'use client'

import { useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { FileCode, Trash2, Plus } from 'lucide-react'
import { toast } from 'sonner'

interface File {
  id: string
  name: string
  language: string
  content: string
}

interface VirtualFileListProps {
  files: File[]
  activeFileId: string
  onFileSelect: (fileId: string) => void
  onFileDelete: (fileId: string) => void
  onFileCreate: () => void
}

export default function VirtualFileList({
  files,
  activeFileId,
  onFileSelect,
  onFileDelete,
  onFileCreate
}: VirtualFileListProps) {
  const parentRef = useRef<HTMLDivElement>(null)

  const estimateSize = useCallback(() => 40, [])
  const rowVirtualizer = useVirtualizer({
    count: files.length,
    getScrollElement: () => parentRef.current,
    estimateSize,
    overscan: 5
  })

  const getLanguageBadge = (language: string) => {
    const colors: Record<string, string> = {
      typescript: 'bg-blue-500',
      javascript: 'bg-yellow-500',
      python: 'bg-green-500',
      html: 'bg-orange-500',
      css: 'bg-purple-500',
      json: 'bg-red-500',
      markdown: 'bg-gray-500'
    }
    return colors[language] || 'bg-gray-500'
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-3 border-b">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Files</span>
          <Badge variant="secondary">{files.length} files</Badge>
        </div>
        <Button size="sm" variant="ghost" onClick={onFileCreate}>
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      <div
        ref={parentRef}
        className="flex-1 overflow-auto"
        style={{
          position: 'relative',
          height: 'calc(100% - 50px)'
        }}
      >
        <div
          style={{
            height: `${rowVirtualizer.getTotalSize()}px`,
            width: '100%',
            position: 'relative'
          }}
        >
          {rowVirtualizer.getVirtualItems().map((virtualRow) => {
            const file = files[virtualRow.index]
            const isActive = file.id === activeFileId

            return (
              <div
                key={virtualRow.key}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: `${virtualRow.size}px`,
                  transform: `translateY(${virtualRow.start}px)`,
                }}
                className={`
                  flex items-center gap-2 px-3 py-2 cursor-pointer transition-colors
                  border-b
                  ${isActive ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-muted/50 border-transparent'}
                `}
                onClick={() => onFileSelect(file.id)}
              >
                <FileCode className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-primary-foreground' : 'text-muted-foreground'}`} />
                <span className="flex-1 min-w-0 text-sm truncate">{file.name}</span>
                <div className={`flex items-center gap-1 flex-shrink-0 ${isActive ? 'opacity-50' : 'opacity-100 hover:opacity-100'}`}>
                  <Badge variant="outline" className="text-xs">
                    {file.language}
                  </Badge>
                  {files.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        onFileDelete(file.id)
                      }}
                      className="p-1 hover:text-destructive"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {files.length === 0 && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          <div className="text-center">
            <FileCode className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">No files yet</p>
            <p className="text-xs mt-1">Click + to create your first file</p>
          </div>
        </div>
      )}
    </div>
  )
}
